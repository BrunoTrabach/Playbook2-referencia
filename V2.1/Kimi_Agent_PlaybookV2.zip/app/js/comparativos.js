/* ============================================
   AIWA PLAYBOOK V2 - COMPARATIVOS.JS
   Motor de comparacao dinamica
   Suporta comparativos 1x1 ate 1x5
   ============================================ */

// Este arquivo complementa o app.js com funcoes especificas
// de comparativos que foram centralizadas no app.js para
// melhor performance e manutencao.

// As funcoes principais de comparativos estao no app.js:
// - renderComparisonPage(type)
// - renderAudioComparison()
// - updateAudioComparison()
// - renderACComparison()
// - updateACComparison()

// Este arquivo esta reservado para futuras extensoes como:
// - Exportacao de comparativos para PDF
// - Comparativos salvos
// - Compartilhamento de comparativos
// - Novas categorias de produtos

const ComparativosEngine = {

  // Configuracoes de comparacao
  config: {
    maxCompetitors: 5,
    categories: ['audio', 'ar-condicionado'],
    displayMode: 'grid' // grid ou table
  },

  // Estado atual da comparacao
  state: {
    category: null,
    aiwaProduct: null,
    competitors: [],
    lastUpdate: null
  },

  // Inicializa o motor de comparativos
  init: function(category) {
    this.state.category = category;
    this.state.competitors = [];
    console.log(`[Comparativos] Motor inicializado para categoria: ${category}`);
  },

  // Seleciona produto AIWA
  selectAiwa: function(productId) {
    this.state.aiwaProduct = productId;
    this.state.lastUpdate = new Date();
  },

  // Adiciona/remove concorrente
  toggleCompetitor: function(productId) {
    const idx = this.state.competitors.indexOf(productId);
    if (idx >= 0) {
      this.state.competitors.splice(idx, 1);
    } else if (this.state.competitors.length < this.config.maxCompetitors) {
      this.state.competitors.push(productId);
    }
    this.state.lastUpdate = new Date();
  },

  // Retorna produtos selecionados para comparacao
  getSelectedProducts: function() {
    if (!this.state.category) return [];

    const db = this.state.category === 'audio' ? DB.audioProducts : DB.acProducts;
    const aiwaProduct = db.aiwa.find(p => p.id === this.state.aiwaProduct) || db.aiwa[0];
    const competitors = this.state.competitors
      .map(id => db.competitors.find(c => c.id === id))
      .filter(Boolean);

    return [aiwaProduct, ...competitors];
  },

  // Calcula vencedor por criterio
  getWinner: function(spec) {
    const products = this.getSelectedProducts();
    if (products.length < 2) return null;

    // Mapeia especificacoes numericas
    const scores = products.map(p => {
      let val = p[spec];
      if (typeof val === 'boolean') return val ? 1 : 0;
      if (typeof val === 'string') {
        // Extrai numeros de strings como "100W", "30h", "R$ 599"
        const num = parseFloat(val.replace(/[^0-9.]/g, ''));
        return isNaN(num) ? 0 : num;
      }
      return 0;
    });

    const maxScore = Math.max(...scores);
    const winnerIdx = scores.indexOf(maxScore);

    // Se AIWA ganhou, retorna o id
    return winnerIdx === 0 ? products[0].id : null;
  },

  // Gera resumo textual do comparativo
  generateSummary: function() {
    const products = this.getSelectedProducts();
    if (products.length < 2) return '';

    const aiwa = products[0];
    const others = products.slice(1);

    let summary = `## Comparativo: ${aiwa.name} vs ${others.map(o => o.name).join(', ')}\n\n`;
    summary += `**AIWA ${aiwa.name}**\n`;
    summary += `- Potencia: ${aiwa.power || aiwa.btu || '-'}\n`;
    summary += `- Preco: ${aiwa.price}\n\n`;

    others.forEach(o => {
      summary += `**${o.brand} ${o.name}**\n`;
      summary += `- Potencia: ${o.power || o.btu || '-'}\n`;
      summary += `- Preco: ${o.price}\n\n`;
    });

    return summary;
  },

  // Futuro: exportar para PDF
  exportToPDF: function() {
    console.log('[Comparativos] Exportacao para PDF sera implementada na v3');
    alert('Exportacao para PDF disponivel na proxima versao!');
  },

  // Futuro: compartilhar comparativo
  shareComparison: function() {
    const summary = this.generateSummary();
    if (navigator.share) {
      navigator.share({
        title: 'Comparativo AIWA',
        text: summary
      });
    } else {
      navigator.clipboard.writeText(summary);
      alert('Resumo copiado para a area de transferencia!');
    }
  },

  // Salvar comparativo nos favoritos
  saveComparison: function() {
    const products = this.getSelectedProducts();
    if (products.length < 2) return;

    const title = `Comparativo: ${products[0].name} vs ${products.length - 1} concorrentes`;
    toggleFavorite(
      `compare-${Date.now()}`,
      title,
      'Comparativos'
    );
  }

};
