/* ============================================
   AIWA PLAYBOOK V2 - DATABASE.JS
   Dados completos: Historias, Comparativos,
   Tecnologias, Pilares, Dicas, Perfis
   ============================================ */

const DB = {

  // ==========================================
  // PERFIS DOS PERSONAGENS
  // ==========================================
  profiles: {
    bruno: {
      name: 'Bruno Trabach',
      role: 'Promotor AIWA',
      avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
      bio: 'Promotor AIWA especializado em treinamentos, demonstracoes e suporte a equipe de vendas. Experiencia em campo com audio e tecnologia.',
      skills: ['Treinamento', 'Demonstracoes', 'Suporte Tecnico', 'Fechamento', 'Relacionamento']
    },
    cristiane: {
      name: 'Cristiane',
      role: 'Cliente',
      avatar: 'assets/avatares/Cristiane_cliente.jpg',
      bio: 'Cliente que descobriu a AIWA e se apaixonou pela qualidade sonora. Tornou-se fa da marca e indicou amigos.',
      tags: ['Primeira Compra', 'Pos-Venda', 'Indicacao', 'Fiel']
    },
    edy: {
      name: 'Edy',
      role: 'Vendedor',
      avatar: 'assets/avatares/Edy_Vendedor.jpg',
      bio: 'Vendedor da loja que aprendeu com Bruno a vender AIWA. Desenvolveu autonomia e confianca nos produtos.',
      skills: ['Vendas', 'Atendimento', 'Aprendizado', 'Autonomia']
    },
    fernanda: {
      name: 'Fernanda',
      role: 'Indicacao',
      avatar: 'assets/avatares/Fernanda_cliente.jpg',
      bio: 'Amiga de Cristiane que foi indicada e tambem se tornou cliente AIWA. Representa o poder da prova social.',
      tags: ['Indicacao', 'Nova Cliente', 'Prova Social']
    }
  },

  // ==========================================
  // DICAS DO DIA
  // ==========================================
  tips: [
    {
      id: 1,
      text: 'Sempre inicie a demonstracao com a musica que o cliente gosta. A conexao emocional e metade da venda.'
    },
    {
      id: 2,
      text: 'Destaque o IP6 quando o cliente mencionar festas na piscina ou praia. E um diferencial que a concorrencia nao tem.'
    },
    {
      id: 3,
      text: 'Use o TWS para impressionar: conectar duas caixas e mostrar o estereo potente fecha vendas na hora.'
    },
    {
      id: 4,
      text: 'Mostre o App AIWA Audio BR. O equalizador personalizado e um argumento de venda poderoso.'
    },
    {
      id: 5,
      text: 'A bateria de 30 horas + powerbank e um combo que nenhum concorrente oferece. Use sem moderasao.'
    },
    {
      id: 6,
      text: 'Bass Boost nao e so volume. E qualidade de grave profundo. Pecra para o cliente sentir a diferenca.'
    },
    {
      id: 7,
      text: 'Bluetooth 5.3 significa conexao estavel ate 10m. Ideal para quem quer liberdade de movimento.'
    },
    {
      id: 8,
      text: 'A historia da AIWA desde 1951 gera confianca. Mencione a origem japonesa e o Grupo MK.'
    },
    {
      id: 9,
      text: 'Em comparativos, nao fale mal da concorrencia. Mostre os diferenciais AIWA com dados e demonstracao.'
    },
    {
      id: 10,
      text: 'Siga o cliente no pos-venda. Uma mensagem de agradecimento gera indicacoes. Veja a Historia 3.'
    }
  ],

  // ==========================================
  // HISTORIAS
  // ==========================================
  stories: {
    1: {
      id: 1,
      title: 'Primeira Venda',
      subtitle: 'Cristiane conhece a AIWA',
      objective: 'Mostrar abordagem, demonstracao e fechamento.',
      characters: ['bruno', 'edy', 'cristiane'],
      tags: ['Abordagem', 'Demonstracao', 'Fechamento'],
      scenes: [
        {
          num: 1,
          setting: 'Loja de eletronicos - Setor de Audio',
          lines: [
            {
              speaker: 'Cristiane',
              avatar: 'assets/avatares/Cristiane_cliente.jpg',
              text: 'Oi, estou procurando uma caixa de som para uma festa que vou fazer no fim de semana. Algo potente, mas que nao seja muito cara.'
            },
            {
              speaker: 'Edy',
              avatar: 'assets/avatares/Edy_Vendedor.jpg',
              text: 'Ola! Temos varias opcoes. Qual o seu orcamento mais ou menos?'
            },
            {
              speaker: 'Cristiane',
              avatar: 'assets/avatares/Cristiane_cliente.jpg',
              text: 'Algo em torno de R$ 500 a R$ 800. Quero que toque bem alto, com bastante grave.'
            },
            {
              action: true,
              text: 'Bruno, o promotor AIWA, observa a conversa e se aproxima.'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Edy, posso ajudar? Acho que tenho a caixa perfeita para essa cliente.'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Ola, Cristiane! Eu sou o Bruno, promotor AIWA. Posso te mostrar algo que vai te surpreender?'
            }
          ],
          lesson: {
            title: 'Tecnica: Abordagem Colaborativa',
            points: [
              'Nao interrompa o vendedor. Espere o momento certo.',
              'Peca permissao para participar. Respeito gera confianca.',
              'Use o nome do cliente. Personalizacao e poder.'
            ]
          }
        },
        {
          num: 2,
          setting: 'Bancada de Demonstracao AIWA',
          lines: [
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Cristiane, deixa eu te apresentar a AWS-100. Ela tem 100W de potencia real, Bluetooth 5.3, e uma protecao IP66 que aguenta poeira e agua. Perfeita para festas ao ar livre.'
            },
            {
              speaker: 'Cristiane',
              avatar: 'assets/avatares/Cristiane_cliente.jpg',
              text: 'Nossa, ela e bonita! E essa protecao IP66 significa o que, exatamente?'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Significa que voce pode usar na beira da piscina, na praia, ou ate levar um spray sem se preocupar. A caixa e praticamente a prova de agua e poeira.'
            },
            {
              action: true,
              text: 'Bruno conecta o celular ao Bluetooth. A conexao e instantanea.'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Me fala: qual tipo de musica voce gosta? Vou tocar algo que voce conheca para sentir a qualidade.'
            },
            {
              speaker: 'Cristiane',
              avatar: 'assets/avatares/Cristiane_cliente.jpg',
              text: 'Adoro sertanejo e um pagode. Tem alguma coisa assim ai?'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Perfeito! Deixa eu tocar um sertanejo aqui... Escuta esse grave. Voce sente a diferenca?'
            }
          ],
          lesson: {
            title: 'Tecnica: Demonstracao Personalizada',
            points: [
              'Pergunte a musica preferida do cliente. Conexao emocional e fundamental.',
              'Destaque o IP6 para uso externo. E um diferencial exclusivo.',
              'Mostre, nao apenas diga. A experiencia sensorial convence mais que palavras.'
            ]
          }
        },
        {
          num: 3,
          setting: 'Demonstracao ao Vivo',
          lines: [
            {
              action: true,
              text: 'A musica comeca. O grave e profundo e impactante. Cristiane sorri, claramente impressionada.'
            },
            {
              speaker: 'Cristiane',
              avatar: 'assets/avatares/Cristiane_cliente.jpg',
              text: 'Uau! Esse grave e muito forte! Parece que eu estou no show. E o volume, da para aumentar mais?'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Claro! E olha so: temos o Bass Boost ativado. Quer que eu mostre a diferenca com e sem?'
            },
            {
              speaker: 'Cristiane',
              avatar: 'assets/avatares/Cristiane_cliente.jpg',
              text: 'Nossa, sim! Quero ver!'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Com Bass Boost: o grave e profundo, encorpado. Agora sem: ainda e boa, mas perde aquela imersao. A maioria dos concorrentes nao tem essa tecnologia.'
            },
            {
              speaker: 'Cristiane',
              avatar: 'assets/avatares/Cristiane_cliente.jpg',
              text: 'A diferenca e enorme! E a bateria, quanto dura? Minha festa pode ir ate de madrugada...'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Ate 30 horas de reproducao. Sua festa pode ir ate amanhecer e a caixa vai aguentar. E ainda serve como powerbank para carregar seu celular.'
            }
          ],
          lesson: {
            title: 'Tecnica: Argumentos que Fecham',
            points: [
              'Bass Boost ON/OFF e um demo poderoso. O cliente sente a diferenca.',
              '30 horas de bateria elimina objecao sobre durabilidade.',
              'Powerbank e um bonus inesperado que agrega valor.'
            ]
          }
        },
        {
          num: 4,
          setting: 'Fechamento da Venda',
          lines: [
            {
              speaker: 'Cristiane',
              avatar: 'assets/avatares/Cristiane_cliente.jpg',
              text: 'Gostei muito! E quanto custa?'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Essa caixa esta saindo por R$ 599. Mas tem mais: voce pode conectar duas caixas iguais via TWS e ter um som estereo ainda mais potente.'
            },
            {
              speaker: 'Cristiane',
              avatar: 'assets/avatares/Cristiane_cliente.jpg',
              text: 'TWS? O que e isso?'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'True Wireless Stereo. Voce pega duas caixas AWS-100, conecta uma no celular, e a outra se conecta automaticamente na primeira. Resultado: som estereo com o dobro da potencia. Ideal para festas maiores.'
            },
            {
              speaker: 'Cristiane',
              avatar: 'assets/avatares/Cristiane_cliente.jpg',
              text: 'Nossa, que legal! Mas por enquanto vou levar uma so. Estou apaixonada!'
            },
            {
              speaker: 'Edy',
              avatar: 'assets/avatares/Edy_Vendedor.jpg',
              text: 'Perfeito, Cristiane! Vou fazer a nota para voce. A caixa tem garantia de 1 ano e voce pode baixar o App AIWA Audio BR para controlar o equalizador.'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Deixa eu te ajudar a instalar o app. Com ele voce pode ajustar os graves, ativar o Bass Boost, e ate salvar seus presets favoritos. Quer que eu te mostre?'
            },
            {
              speaker: 'Cristiane',
              avatar: 'assets/avatares/Cristiane_cliente.jpg',
              text: 'Quero sim! Muito obrigada, Bruno. Voce foi super atencioso!'
            }
          ],
          lesson: {
            title: 'Tecnica: Fechamento e Pos-Venda Imediato',
            points: [
              'Mencione TWS como upsell, mas sem pressionar. A informacao ja planta a semente.',
              'Ajude a instalar o app no momento da compra. Engajamento imediato.',
              'Deixe o cliente feliz. Satisfacao gera indicacao. (Ver Historia 3)'
            ]
          }
        }
      ]
    },
    2: {
      id: 2,
      title: 'Pos-Venda',
      subtitle: 'Cristiane retorna com duvidas',
      objective: 'Mostrar suporte, aplicativo, IP66, TWS e relacionamento.',
      characters: ['bruno', 'cristiane'],
      tags: ['Suporte', 'App AIWA', 'IP66', 'TWS'],
      scenes: [
        {
          num: 1,
          setting: 'Loja - Uma semana depois',
          lines: [
            {
              speaker: 'Cristiane',
              avatar: 'assets/avatares/Cristiane_cliente.jpg',
              text: 'Ola, Bruno! Lembra de mim? Comprei a caixa semana passada.'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Claro que lembro, Cristiane! Como foi a festa? Curtiu a caixa?'
            },
            {
              speaker: 'Cristiane',
              avatar: 'assets/avatares/Cristiane_cliente.jpg',
              text: 'A festa foi incrivel! Todo mundo elogiou o som. Mas vim porque tenho algumas duvidas sobre o app e algumas funcoes.'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Fico feliz que gostou! Pode perguntar, estou aqui para ajudar.'
            }
          ],
          lesson: {
            title: 'Tecnica: Recepcao no Pos-Venda',
            points: [
              'Sempre reconheca o cliente. Use o nome e faca referencia a compra.',
              'Pergunte sobre a experiencia. Interesse genuino fortalece relacionamento.',
              'Receba duvidas com entusiasmo. Pos-venda e nova oportunidade de venda.'
            ]
          }
        },
        {
          num: 2,
          setting: 'Demonstrando o App AIWA Audio BR',
          lines: [
            {
              speaker: 'Cristiane',
              avatar: 'assets/avatares/Cristiane_cliente.jpg',
              text: 'Consegui instalar o app, mas nao entendi muito bem o equalizador. Tem varios botoes.'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Vou te mostrar! O equalizador te permite ajustar os graves, medios e agudos. Olha: aqui voce aumenta o grave para funk e sertanejo. Aqui voce deixa mais equilibrado para rock e pop.'
            },
            {
              speaker: 'Cristiane',
              avatar: 'assets/avatares/Cristiane_cliente.jpg',
              text: 'Ah, agora entendi! E esses presets aqui em cima?'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Sao configuracoes prontas. Voce toca aqui em Flat, Bass, Treble, ou Outdoor. Cada um e otimizado para um tipo de musica ou ambiente. O Outdoor aumenta tudo para competir com ruido externo.'
            },
            {
              action: true,
              text: 'Cristiane testa o preset Bass. A caixa reage instantaneamente.'
            },
            {
              speaker: 'Cristiane',
              avatar: 'assets/avatares/Cristiane_cliente.jpg',
              text: 'Nossa, mudou completamente! Fica muito melhor para o funk que eu gosto!'
            }
          ],
          lesson: {
            title: 'Tecnica: Educacao do Cliente',
            points: [
              'Mostre o app pessoalmente. Tutoriais sozinhos geram frustracao.',
              'Deixe o cliente experimentar. Aprender fazendo gera confianca.',
              'Explique presets como atalhos. Simplifique a tecnologia.'
            ]
          }
        },
        {
          num: 3,
          setting: 'Duvidas sobre IP66 e TWS',
          lines: [
            {
              speaker: 'Cristiane',
              avatar: 'assets/avatares/Cristiane_cliente.jpg',
              text: 'Mais uma coisa: posso realmente usar na beira da piscina sem medo?'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Com certeza! IP66 significa protecao total contra poeira e jatos de agua. Pode pegar espirro de piscina, chuva, ate lavar a caixa com agua corrente depois da praia. So nao mergulha, ok?'
            },
            {
              speaker: 'Cristiane',
              avatar: 'assets/avatares/Cristiane_cliente.jpg',
              text: 'Que otimo! E aquele negocio de conectar duas caixas? Ainda estou pensando em comprar outra para o Natal...'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'O TWS! E super facil: liga as duas caixas, segura o botao TWS em uma delas, e elas se pareiam sozinhas. Ai voce conecta o celular em uma e as duas tocam juntas em estereo.'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Fica com 200W de potencia total. E o estereo separa as faixas esquerda e direita. A sensacao e de estar no meio da musica.'
            },
            {
              speaker: 'Cristiane',
              avatar: 'assets/avatares/Cristiane_cliente.jpg',
              text: 'Perfeito! Vou comprar a segunda com certeza. Voce me converteu de novo, Bruno!'
            }
          ],
          lesson: {
            title: 'Tecnica: Upsell Natural',
            points: [
              'Explique IP66 com exemplos praticos. Teoria nao convence.',
              'TWS e argumento de upsell perfeito. O cliente ja experimentou.',
              'Deixe o cliente chegar a conclusao sozinho. Venda suave e mais efetiva.'
            ]
          }
        }
      ]
    },
    3: {
      id: 3,
      title: 'Indicacao',
      subtitle: 'Cristiane traz Fernanda',
      objective: 'Mostrar prova social, indicacao, nova venda e confianca.',
      characters: ['bruno', 'cristiane', 'fernanda'],
      tags: ['Prova Social', 'Indicacao', 'Nova Venda'],
      scenes: [
        {
          num: 1,
          setting: 'Loja - Duas semanas depois',
          lines: [
            {
              speaker: 'Cristiane',
              avatar: 'assets/avatares/Cristiane_cliente.jpg',
              text: 'Bruno, essa e a minha amiga Fernanda. Eu nao paro de falar da minha caixa AIWA e ela veio ver de perto.'
            },
            {
              speaker: 'Fernanda',
              avatar: 'assets/avatares/Fernanda_cliente.jpg',
              text: 'Ola! A Cris nao para de falar desse som dela. Toquei na festa dela e fiquei impressionada. Quero uma igual!'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Ola, Fernanda! Seja bem-vinda! Fico feliz que gostou da festa da Cristiane. Ela tem uma AWS-100, ne?'
            },
            {
              speaker: 'Cristiane',
              avatar: 'assets/avatares/Cristiane_cliente.jpg',
              text: 'Sim! E ja comprei a segunda pelo TWS. Agora tenho o dobro da potencia. Fernanda, voce precisa ver isso!'
            }
          ],
          lesson: {
            title: 'Tecnica: Prova Social em Acao',
            points: [
              'Cliente indicando e o melhor marketing possivel. Valorize!',
              'Deixe o cliente falar bem do produto. Nao interrompa.',
              'Mencione a segunda compra (TWS) como reforco.'
            ]
          }
        },
        {
          num: 2,
          setting: 'Demonstracao para Fernanda',
          lines: [
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Fernanda, como a Cristiane ja conhece tudo, vou focar no que voce precisa saber. Qual o seu estilo de musica?'
            },
            {
              speaker: 'Fernanda',
              avatar: 'assets/avatares/Fernanda_cliente.jpg',
              text: 'Eu curto mais pop e eletronica. Gosto de festas com bastante energia.'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Perfeito! Deixa eu tocar uma musica eletronica com o Bass Boost ativado...'
            },
            {
              action: true,
              text: 'A musica eletronica toca com graves profundos e agudos cristalinos. Fernanda balanca a cabeca, visivelmente impressionada.'
            },
            {
              speaker: 'Fernanda',
              avatar: 'assets/avatares/Fernanda_cliente.jpg',
              text: 'Nossa! O grave e muito mais forte que na JBL da minha irma! E essa iluminacao?'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'As luzes LED sincronizam com a batida. Tem varios modos e voce controla tudo pelo app. Quer ver?'
            },
            {
              speaker: 'Cristiane',
              avatar: 'assets/avatares/Cristiane_cliente.jpg',
              text: 'O app e demais, Fernanda! Voce pode mudar as cores, criar preset... eu uso o modo Outdoor quando vou para a praia.'
            }
          ],
          lesson: {
            title: 'Tecnica: Venda com Testemunho',
            points: [
              'Personalize a demo para o novo cliente. Nao repita a mesma coisa.',
              'Deixe o cliente anterior participar. Testemunho e mais forte que vendedor.',
              'Compare sutilmente com concorrentes. Deixe o cliente notar.'
            ]
          }
        },
        {
          num: 3,
          setting: 'Fechamento',
          lines: [
            {
              speaker: 'Fernanda',
              avatar: 'assets/avatares/Fernanda_cliente.jpg',
              text: 'Estou vendida! Quanto custa?'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'R$ 599. E se voce quiser, temos a opcao de pagamento em ate 10x sem juros.'
            },
            {
              speaker: 'Fernanda',
              avatar: 'assets/avatares/Fernanda_cliente.jpg',
              text: 'Perfeito! Vou levar. E ja vou baixar o app igual a Cristiane fez.'
            },
            {
              speaker: 'Cristiane',
              avatar: 'assets/avatares/Cristiane_cliente.jpg',
              text: 'Bruno, muito obrigada pelo atendimento de sempre. Voce e o melhor!'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Obrigado a voce, Cristiane, por indicar a Fernanda! E Fernanda, seja bem-vinda a familia AIWA. Qualquer coisa, estou aqui!'
            }
          ],
          lesson: {
            title: 'Tecnica: Consolidar Relacionamento',
            points: [
              'Agradeca a indicacao publicamente. Cliente se sente valorizado.',
              'Facilite o pagamento. Parcelamento remove barreiras.',
              'Chame de familia. Pertencimento gera lealdade.'
            ]
          }
        }
      ]
    },
    4: {
      id: 4,
      title: 'Treinamento',
      subtitle: 'Bruno ensina Edy',
      objective: 'Mostrar grave, medio, agudo, TWS, app e autonomia da loja.',
      characters: ['bruno', 'edy'],
      tags: ['Treinamento', 'Audio', 'TWS', 'App'],
      scenes: [
        {
          num: 1,
          setting: 'Estoque da Loja - Inicio do turno',
          lines: [
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Edy, hoje vou te ensinar tudo sobre audio para voce vender AIWA sozinho. Pronto?'
            },
            {
              speaker: 'Edy',
              avatar: 'assets/avatares/Edy_Vendedor.jpg',
              text: 'Com certeza! Quero aprender tudo. Os clientes perguntam muita coisa que eu nao sei responder.'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Vamos comecar pelo basico: grave, medio e agudo. Todo som e composto dessas tres frequencias.'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Grave (20-250Hz): e a vibracao profunda. Sertanejo, funk, eletronica dependem disso. Medio (250-4000Hz): e onde esta a voz. Agudo (4000-20000Hz): e o brilho, os pratos, o detalhe.'
            },
            {
              speaker: 'Edy',
              avatar: 'assets/avatares/Edy_Vendedor.jpg',
              text: 'Entendi! E a AIWA tem as tres?'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Tem e muito bem equilibradas. A AWS-100 tem sistema 3 vias: woofer para grave, driver para medio, e tweeter para agudo. Cada um e especializado na sua frequencia.'
            }
          ],
          lesson: {
            title: 'Conhecimento: Audio 3 Vias',
            points: [
              'Grave = impacto. Medio = clareza vocal. Agudo = detalhe.',
              'Sistema 3 vias = speaker dedicado para cada faixa.',
              'Equilibrio entre as tres frequencias = qualidade sonora.'
            ]
          }
        },
        {
          num: 2,
          setting: 'Pratica com o App',
          lines: [
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Agora o app. Baixa ai no seu celular: AIWA Audio BR. E gratis.'
            },
            {
              speaker: 'Edy',
              avatar: 'assets/avatares/Edy_Vendedor.jpg',
              text: 'Baixando... Pronto!'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Conecta a caixa pelo Bluetooth. Agora abre o equalizador. Voce pode mover os controles em tempo real e o som muda na hora.'
            },
            {
              speaker: 'Edy',
              avatar: 'assets/avatares/Edy_Vendedor.jpg',
              text: 'Nossa, que legal! E os presets?'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Flat = neutro, fiel a gravacao original. Bass = maximiza graves. Treble = destaca agudos e voz. Outdoor = tudo no maximo para ambientes abertos.'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Dica: quando o cliente curte funk ou sertanejo, ja coloca no Bass. Se for rock ou pop, o Flat fica perfeito.'
            }
          ],
          lesson: {
            title: 'Conhecimento: App AIWA Audio BR',
            points: [
              'Equalizador em tempo real = demo interativa poderosa.',
              'Presets sao atalhos. Use para personalizar rapido.',
              'Relacione preset com estilo musical do cliente.'
            ]
          }
        },
        {
          num: 3,
          setting: 'Pratica com TWS',
          lines: [
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Agora a parte que mais impressiona: TWS. Pega aquela segunda caixa.'
            },
            {
              action: true,
              text: 'Edy pega a segunda AWS-100.'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Liga as duas. Agora segura o botao TWS na primeira por 3 segundos...'
            },
            {
              action: true,
              text: 'As duas caixas emitem um som de confirmacao e as luzes sincronizam.'
            },
            {
              speaker: 'Edy',
              avatar: 'assets/avatares/Edy_Vendedor.jpg',
              text: 'Conectou! E agora?'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Conecta o celular em uma delas pelo Bluetooth. As duas tocam juntas em estereo. Uma fica com o canal esquerdo, outra com o direito.'
            },
            {
              action: true,
              text: 'A musica comeca. O estereo e envolvente, com separacao clara entre os canais.'
            },
            {
              speaker: 'Edy',
              avatar: 'assets/avatares/Edy_Vendedor.jpg',
              text: 'Caramba! Parece que eu estou no meio da banda! Isso vende sozinho!'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Exatamente! E a bateria continua durando horas porque o TWS nao consome muito mais energia. Ate 30 horas no modo economico.'
            }
          ],
          lesson: {
            title: 'Conhecimento: TWS - True Wireless Stereo',
            points: [
              'Demo de TWS e o momento mais impactante da venda.',
              'Estereo real = separacao esquerda/direita.',
              '30 horas mesmo com TWS ativo.'
            ]
          }
        },
        {
          num: 4,
          setting: 'Autonomia de Vendas',
          lines: [
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Edy, voce ja sabe o suficiente para vender sozinho. Vamos revisar os argumentos principais?'
            },
            {
              speaker: 'Edy',
              avatar: 'assets/avatares/Edy_Vendedor.jpg',
              text: 'Vamos! 100W de potencia real, Bluetooth 5.3, IP66, 30h de bateria, powerbank, app com equalizador, TWS, e Bass Boost. E a AIWA e japonesa desde 1951!'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Perfeito! Voce dominou. Agora lembre-se: nao e so listar recursos. Conecte cada um com a necessidade do cliente.'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Cliente quer festa na piscina? IP66. Quer som potente? 100W + Bass Boost. Quer som para viagem? 30h + powerbank. Quer experiencia premium? TWS + App.'
            },
            {
              speaker: 'Edy',
              avatar: 'assets/avatares/Edy_Vendedor.jpg',
              text: 'Entendi! Adaptar o argumento ao cliente. Obrigado, Bruno! Vou vender muito mais agora!'
            },
            {
              speaker: 'Bruno',
              avatar: 'assets/avatares/Bruno_Promotor_Aiwa.jpg',
              text: 'Isso ai! Qualquer duvida, estou por aqui. Agora vai la e fecha vendas!'
            }
          ],
          lesson: {
            title: 'Tecnica: Argumentacao Personalizada',
            points: [
              'Nao liste recursos. Conecte com necessidades.',
              'Cada cliente tem uma dor principal. Identifique e resolva.',
              'Treinamento constante gera autonomia e confianca.'
            ]
          }
        }
      ]
    }
  },

  // ==========================================
  // COMPARATIVOS - PRODUTOS AUDIO
  // ==========================================
  audioProducts: {
    aiwa: [
      {
        id: 'aws-100',
        name: 'AWS-100',
        brand: 'AIWA',
        type: 'Caixa de Som Portatil',
        power: '100W',
        battery: '30h',
        bluetooth: '5.3',
        waterResistance: 'IP66',
        tws: true,
        bassBoost: true,
        app: true,
        powerbank: true,
        weight: '2.8kg',
        price: 'R$ 599',
        score: 95
      },
      {
        id: 'aws-50',
        name: 'AWS-50',
        brand: 'AIWA',
        type: 'Caixa de Som Portatil',
        power: '50W',
        battery: '20h',
        bluetooth: '5.3',
        waterResistance: 'IP66',
        tws: true,
        bassBoost: true,
        app: true,
        powerbank: false,
        weight: '1.5kg',
        price: 'R$ 349',
        score: 88
      }
    ],
    competitors: [
      {
        id: 'jbl-flip6',
        name: 'Flip 6',
        brand: 'JBL',
        type: 'Caixa de Som Portatil',
        power: '30W',
        battery: '12h',
        bluetooth: '5.1',
        waterResistance: 'IP67',
        tws: true,
        bassBoost: false,
        app: true,
        powerbank: false,
        weight: '0.55kg',
        price: 'R$ 699',
        score: 72
      },
      {
        id: 'jbl-charge5',
        name: 'Charge 5',
        brand: 'JBL',
        type: 'Caixa de Som Portatil',
        power: '40W',
        battery: '20h',
        bluetooth: '5.1',
        waterResistance: 'IP67',
        tws: true,
        bassBoost: false,
        app: true,
        powerbank: true,
        weight: '0.96kg',
        price: 'R$ 899',
        score: 78
      },
      {
        id: 'lg-xboom',
        name: 'XBOOM Go PL7',
        brand: 'LG',
        type: 'Caixa de Som Portatil',
        power: '30W',
        battery: '24h',
        bluetooth: '5.0',
        waterResistance: 'IPX5',
        tws: true,
        bassBoost: false,
        app: false,
        powerbank: false,
        weight: '1.5kg',
        price: 'R$ 549',
        score: 65
      },
      {
        id: 'philco-pbs',
        name: 'PBS220BT',
        brand: 'Philco',
        type: 'Caixa de Som Portatil',
        power: '20W',
        battery: '8h',
        bluetooth: '5.0',
        waterResistance: 'IPX4',
        tws: false,
        bassBoost: false,
        app: false,
        powerbank: false,
        weight: '1.2kg',
        price: 'R$ 199',
        score: 45
      },
      {
        id: 'mondial-cm',
        name: 'CM-550',
        brand: 'Mondial',
        type: 'Caixa de Som Portatil',
        power: '50W',
        battery: '10h',
        bluetooth: '5.0',
        waterResistance: 'IPX5',
        tws: false,
        bassBoost: false,
        app: false,
        powerbank: false,
        weight: '2.1kg',
        price: 'R$ 299',
        score: 55
      },
      {
        id: 'sony-xrs',
        name: 'SRS-XB43',
        brand: 'Sony',
        type: 'Caixa de Som Portatil',
        power: '40W',
        battery: '24h',
        bluetooth: '5.0',
        waterResistance: 'IP67',
        tws: true,
        bassBoost: true,
        app: true,
        powerbank: true,
        weight: '2.7kg',
        price: 'R$ 1.299',
        score: 82
      }
    ]
  },

  // ==========================================
  // COMPARATIVOS - AR CONDICIONADO
  // ==========================================
  acProducts: {
    aiwa: [
      {
        id: 'aiwa-9k',
        name: 'Split 9.000 BTU',
        brand: 'AIWA',
        type: 'Ar Condicionado Split',
        btu: '9.000',
        inverter: true,
        energyClass: 'A+++',
        wifi: true,
        app: true,
        silent: '19dB',
        filter: 'MPF + Ion',
        gas: 'R-32',
        warranty: '5 anos',
        price: 'R$ 1.899',
        score: 92
      },
      {
        id: 'aiwa-12k',
        name: 'Split 12.000 BTU',
        brand: 'AIWA',
        type: 'Ar Condicionado Split',
        btu: '12.000',
        inverter: true,
        energyClass: 'A+++',
        wifi: true,
        app: true,
        silent: '20dB',
        filter: 'MPF + Ion',
        gas: 'R-32',
        warranty: '5 anos',
        price: 'R$ 2.299',
        score: 94
      }
    ],
    competitors: [
      {
        id: 'lg-dual',
        name: 'Dual Inverter 9.000',
        brand: 'LG',
        type: 'Ar Condicionado Split',
        btu: '9.000',
        inverter: true,
        energyClass: 'A++',
        wifi: true,
        app: true,
        silent: '19dB',
        filter: '3M',
        gas: 'R-32',
        warranty: '10 anos compressor',
        price: 'R$ 2.299',
        score: 88
      },
      {
        id: 'samsung-wind',
        name: 'WindFree 9.000',
        brand: 'Samsung',
        type: 'Ar Condicionado Split',
        btu: '9.000',
        inverter: true,
        energyClass: 'A++',
        wifi: true,
        app: true,
        silent: '21dB',
        filter: 'Easy + Ion',
        gas: 'R-32',
        warranty: '10 anos compressor',
        price: 'R$ 2.599',
        score: 90
      },
      {
        id: 'electrolux-eco',
        name: 'EcoTurbo 9.000',
        brand: 'Electrolux',
        type: 'Ar Condicionado Split',
        btu: '9.000',
        inverter: true,
        energyClass: 'A+',
        wifi: false,
        app: false,
        silent: '24dB',
        filter: 'Standard',
        gas: 'R-410A',
        warranty: '5 anos',
        price: 'R$ 1.699',
        score: 70
      },
      {
        id: 'midea-nova',
        name: 'Nova 9.000',
        brand: 'Midea',
        type: 'Ar Condicionado Split',
        btu: '9.000',
        inverter: true,
        energyClass: 'A++',
        wifi: true,
        app: true,
        silent: '22dB',
        filter: 'Prata + Ion',
        gas: 'R-32',
        warranty: '10 anos compressor',
        price: 'R$ 1.999',
        score: 82
      },
      {
        id: 'springer-midea',
        name: 'Midea Springer 9.000',
        brand: 'Springer',
        type: 'Ar Condicionado Split',
        btu: '9.000',
        inverter: true,
        energyClass: 'A+',
        wifi: false,
        app: false,
        silent: '25dB',
        filter: 'Standard',
        gas: 'R-410A',
        warranty: '5 anos',
        price: 'R$ 1.599',
        score: 68
      }
    ]
  },

  // ==========================================
  // TECNOLOGIAS
  // ==========================================
  technologies: {
    bluetooth: {
      id: 'bluetooth',
      name: 'Bluetooth 5.3',
      icon: '&#128246;',
      category: 'Conectividade',
      summary: 'A ultima geracao do Bluetooth oferece maior alcance, estabilidade e baixa latencia.',
      sections: [
        {
          title: 'O que e Bluetooth 5.3?',
          icon: '&#128161;',
          content: 'O Bluetooth 5.3 e a versao mais recente do padrao de conectividade sem fio. Lancado em 2021, trouxe melhorias significativas em relacao as versoes anteriores, especialmente no que diz respeito a estabilidade, eficiencia energetica e qualidade de conexao.'
        },
        {
          title: 'Vantagens do Bluetooth 5.3',
          icon: '&#9989;',
          items: [
            'Alcance de ate 10 metros sem obstaculos (o dobro do 4.2)',
            'Conexao mais estavel com menos quedas de sinal',
            'Baixa latencia para sincronia perfeita audio/video',
            'Menor consumo de bateria do dispositivo conectado',
            'Suporte a multiplos dispositivos simultaneamente',
            'Reconexao automatica instantanea'
          ]
        },
        {
          title: 'Bluetooth 5.3 vs Versoes Anteriores',
          icon: '&#128200;',
          comparison: [
            { spec: 'Alcance', v53: '10m+', v52: '10m', v42: '5m' },
            { spec: 'Latencia', v53: 'Baixissima', v52: 'Baixa', v42: 'Alta' },
            { spec: 'Estabilidade', v53: 'Excelente', v52: 'Boa', v42: 'Regular' },
            { spec: 'Consumo', v53: 'Minimo', v52: 'Baixo', v42: 'Alto' },
            { spec: 'Multiponto', v53: 'Sim', v52: 'Sim', v42: 'Limitado' }
          ]
        },
        {
          title: 'Beneficios na Pratica',
          icon: '&#127897;',
          items: [
            'Conecte seu celular e ande pela casa sem interrupcoes',
            'Assista videos sem delay entre audio e imagem',
            'Use o speaker por horas sem drenar a bateria do celular',
            'Alterne rapidamente entre celular e tablet',
            'Conexao confiavel mesmo em ambientes com muitas redes WiFi'
          ]
        }
      ]
    },
    tws: {
      id: 'tws',
      name: 'TWS - True Wireless Stereo',
      icon: '&#127900;',
      category: 'Audio',
      summary: 'Conecte duas caixas AIWA wireless para criar um sistema estereo com o dobro da potencia.',
      sections: [
        {
          title: 'O que e TWS?',
          icon: '&#128161;',
          content: 'TWS (True Wireless Stereo) e uma tecnologia que permite conectar duas caixas de som sem fio, criando um sistema de audio estereo verdadeiro. Uma caixa reproduz o canal esquerdo (L) e a outra o canal direito (R), resultando em uma experiencia sonora imersiva e com o dobro da potencia.'
        },
        {
          title: 'Como Funciona?',
          icon: '&#9881;',
          items: [
            'Ligue as duas caixas AIWA compativeis',
            'Pressione o botao TWS em uma delas por 3 segundos',
            'As caixas se pareiam automaticamente (som de confirmacao)',
            'Conecte seu celular via Bluetooth a uma delas',
            'As duas caixas tocam sincronizadas em estereo',
            'Alcance entre as caixas: ate 10 metros'
          ]
        },
        {
          title: 'Vantagens do TWS',
          icon: '&#11088;',
          items: [
            'Dobre a potencia: 100W vira 200W',
            'Experiencia estereo verdadeira com separacao L/R',
            'Som ambiente perfeito para festas e eventos',
            'Sem fios entre as caixas - total liberdade de posicionamento',
            'Configuracao em segundos, sem necessidade de app',
            'Funciona com todas as caixas AIWA compativeis'
          ]
        },
        {
          title: 'Ideais de Uso',
          icon: '&#127881;',
          items: [
            'Festas: posicione as caixas nos cantos opostos do ambiente',
            'Piscina: uma caixa de cada lado da area de lazer',
            'Area gourmet: som envolvente para churrasco e reunioes',
            'Comercio: som ambiente uniforme em toda a loja',
            'Praia: duas caixas para cobrir toda a area do grupo'
          ]
        }
      ]
    },
    ip66: {
      id: 'ip66',
      name: 'IP66 - Protecao Total',
      icon: '&#128167;',
      category: 'Durabilidade',
      summary: 'Protecao completa contra poeira, agua e impactos para usar em qualquer lugar.',
      sections: [
        {
          title: 'O que significa IP66?',
          icon: '&#128161;',
          content: 'IP (Ingress Protection) e um padrao internacional que classifica o nivel de protecao de equipamentos contra a entrada de solidos e liquidos. O codigo IP66 significa protecao total contra poeira (6) e resistencia a jatos de agua potentes (6).'
        },
        {
          title: 'Primeiro Digito: Protecao contra Solidos',
          icon: '&#128230;',
          items: [
            'Nivel 6 = Protecao total contra poeira',
            'Areia de praia nao entra nos componentes internos',
            'Particulas de sujeira nao afetam o funcionamento',
            'Protecao total ao redor de construcoes e obras',
            'Uso seguro em ambientes com poeira intensa'
          ]
        },
        {
          title: 'Segundo Digito: Protecao contra Liquidos',
          icon: '&#128167;',
          items: [
            'Nivel 6 = Resiste a jatos de agua potentes',
            'Chuva forte nao danifica a caixa',
            'Sutilhos de piscina sao suportados sem problemas',
            'Pode lavar a caixa com agua corrente apos uso na praia',
            'Resistente a espirros acidentais de bebidas'
          ]
        },
        {
          title: 'Cenarios de Uso',
          icon: '&#127958;',
          items: [
            'Praia: areia e agua do mar nao entram',
            'Piscina: espirros e chuva de piscina sao suportados',
            'Churrasco: sem medo de respingos de bebidas',
            'Camping: poeira e terra nao afetam o funcionamento',
            'Obra: ambiente de po resistido com sucesso',
            'Lavagem: limpe a caixa com agua apos o uso'
          ]
        },
        {
          title: 'IP66 vs Outros Niveis',
          icon: '&#128200;',
          comparison: [
            { level: 'IPX4', dust: '-', water: 'Respingos', usage: 'Uso interno' },
            { level: 'IPX5', dust: '-', water: 'Jatos leves', usage: 'Area gourmet' },
            { level: 'IP55', dust: 'Poeira limitada', water: 'Jatos leves', usage: 'Externo parcial' },
            { level: 'IP66', dust: 'Total', water: 'Jatos fortes', usage: 'Qualquer lugar' },
            { level: 'IP67', dust: 'Total', water: 'Imersao 1m', usage: 'Submersao' }
          ]
        }
      ]
    },
    'app-aiwa': {
      id: 'app-aiwa',
      name: 'App AIWA Audio BR',
      icon: '&#128241;',
      category: 'Aplicativo',
      summary: 'Controle total do seu audio com equalizador, presets e funcoes exclusivas.',
      sections: [
        {
          title: 'Sobre o App',
          icon: '&#128161;',
          content: 'O AIWA Audio BR e o aplicativo oficial da AIWA para controle completo das caixas de som compatíveis. Disponivel para Android e iOS, o app oferece equalizacao avancada, presets inteligentes, controle de iluminacao LED e atualizacoes de firmware.'
        },
        {
          title: 'Principais Funcoes',
          icon: '&#9889;',
          items: [
            'Equalizador grafico com 5 bandas (60Hz a 14kHz)',
            'Presets inteligentes: Flat, Bass, Treble, Outdoor, Custom',
            'Controle de iluminacao LED com multiplos modos',
            'Ajuste de volume fino e balanco estereo',
            'Atualizacao de firmware das caixas',
            'Gerenciamento de conexoes TWS',
            'Tempo de reproducao restante estimado'
          ]
        },
        {
          title: 'Equalizador e Presets',
          icon: '&#127926;',
          items: [
            'Flat: resposta de frequencia neutra e fiel',
            'Bass: realca graves para funk, sertanejo, eletronica',
            'Treble: destaca agudos para jazz, classica, vocal',
            'Outdoor: maximiza todas as frequencias para areas abertas',
            'Custom: salve sua propria configuracao ideal',
            'Ajuste em tempo real enquanto a musica toca'
          ]
        },
        {
          title: 'Como Usar',
          icon: '&#128295;',
          items: [
            'Baixe gratis na Google Play ou App Store',
            'Ative o Bluetooth do celular',
            'Ligue a caixa AIWA e conecte pelo Bluetooth',
            'Abra o app - a caixa sera detectada automaticamente',
            'Explore as funcoes e ajuste ao seu gosto',
            'Salve seus presets favoritos para acesso rapido'
          ]
        }
      ]
    },
    'bass-boost': {
      id: 'bass-boost',
      name: 'Bass Boost',
      icon: '&#127926;',
      category: 'Audio',
      summary: 'Tecnologia exclusiva AIWA que realca os graves para uma experiencia sonora imersiva.',
      sections: [
        {
          title: 'O que e Bass Boost?',
          icon: '&#128161;',
          content: 'Bass Boost e uma tecnologia de processamento de audio desenvolvida pela AIWA que realca as frequencias graves (20-250Hz) de forma inteligente. Diferente de simplesmente aumentar o volume, o Bass Boost adiciona harmonicos e profundidade ao grave, criando uma sensacao de potencia sem distorcer o som.'
        },
        {
          title: 'Como Funciona?',
          icon: '&#9881;',
          items: [
            'Processamento digital de sinal (DSP) otimizado',
            'Realca frequencias graves de 20Hz a 250Hz',
            'Adiciona harmonicos para percepcao de grave mais profundo',
            'Compressao inteligente que evita distorcao',
            'Funciona em qualquer volume sem degradacao',
            'Ativacao por botao fisico ou pelo app'
          ]
        },
        {
          title: 'Bass Boost ON vs OFF',
          icon: '&#127925;',
          comparison: [
            { aspect: 'Profundidade', on: 'Grave profundo e encorpado', off: 'Grave presente mas padrao' },
            { aspect: 'Impacto', on: 'Impacto fisico perceptivel', off: 'Impacto convencional' },
            { aspect: 'Danca', on: 'Ideal para festas e ambientes', off: 'Mais neutro' },
            { aspect: 'Estilos', on: 'Funk, sertanejo, eletronica, pop', off: 'Jazz, classica, vocal' },
            { aspect: 'Distorcao', on: 'Zero (compressao inteligente)', off: 'Zero' }
          ]
        },
        {
          title: 'Quando Usar',
          icon: '&#127881;',
          items: [
            'Festas: maximize a energia da pista de danca',
            'Externo: graves mais fortes cortam o ruido ambiente',
            'Sertanejo: a sanfona e o grave do violao ganham vida',
            'Funk: o grave e a essencia do ritmo',
            'Eletronica: drops ficam impactantes e imersivos',
            'Filmes: efeitos sonoros e explosoes ganham peso'
          ]
        }
      ]
    },
    bateria: {
      id: 'bateria',
      name: 'Bateria de Longa Duracao',
      icon: '&#128267;',
      category: 'Energia',
      summary: 'Ate 30 horas de reproducao continua com funcao powerbank integrada.',
      sections: [
        {
          title: 'Autonomia AIWA',
          icon: '&#128161;',
          content: 'As caixas de som AIWA utilizam baterias de ions de litio de alta capacidade, otimizadas para longa duracao. A AWS-100 oferece ate 30 horas de reproducao continua em volume medio, o que significa dias de uso sem precisar recarregar.'
        },
        {
          title: 'Especificacoes',
          icon: '&#128295;',
          items: [
            'Tipo: Bateria de ions de litio recarregavel',
            'Capacidade: 10.800mAh (AWS-100)',
            'Autonomia: ate 30 horas (volume 50%)',
            'Autonomia: ate 15 horas (volume maximo)',
            'Tempo de recarga: 4-5 horas (carregador padrao)',
            'Ciclos de vida: 500+ ciclos de recarga',
            'Indicador de bateria no painel e no app'
          ]
        },
        {
          title: 'Funcao Powerbank',
          icon: '&#128268;',
          items: [
            'Porta USB de saida para carregar outros dispositivos',
            'Carregue seu celular enquanto curte a musica',
            'Capacidade suficiente para 2-3 cargas completas de smartphone',
            'Saida de 5V/2A para carregamento rapido',
            'Ativacao automatica ao conectar o cabo USB',
            'Funciona mesmo com a caixa desligada'
          ]
        },
        {
          title: 'Dicas de Uso',
          icon: '&#128161;',
          items: [
            'Volume medio (50-60%) oferece o melhor custo-beneficio de bateria',
            'Desative a iluminacao LED para economizar energia',
            'Use o modo Eco no app para maximizar a autonomia',
            'Evite deixar a bateria descarregar completamente',
            'Recarregue apos cada uso prolongado',
            'Armazene com 50% de carga se nao for usar por semanas'
          ]
        },
        {
          title: 'Comparativo de Autonomia',
          icon: '&#128200;',
          comparison: [
            { model: 'AIWA AWS-100', battery: '30h', powerbank: 'Sim', capacity: '10.800mAh' },
            { model: 'JBL Flip 6', battery: '12h', powerbank: 'Nao', capacity: '4.800mAh' },
            { model: 'JBL Charge 5', battery: '20h', powerbank: 'Sim', capacity: '7.500mAh' },
            { model: 'LG XBOOM PL7', battery: '24h', powerbank: 'Nao', capacity: '7.000mAh' },
            { model: 'Sony SRS-XB43', battery: '24h', powerbank: 'Sim', capacity: '9.000mAh' }
          ]
        }
      ]
    }
  },

  // ==========================================
  // PILARES
  // ==========================================
  pillars: {
    qualidade: {
      id: 'qualidade',
      name: 'Qualidade',
      icon: '&#11088;',
      color: '#E31837',
      summary: 'Potencia real, 3 vias, materiais premium e experiencia sonora superior.',
      sections: [
        {
          title: 'Potencia Real',
          content: 'A AIWA especifica potencia real em RMS (Root Mean Square), nao em valores inflados de pico. A AWS-100 entrega de fato 100W RMS de potencia continua, o que significa volume alto sem distorcao e graves profundos mesmo em volumes elevados.'
        },
        {
          title: 'Sistema 3 Vias',
          content: 'Cada caixa AIWA utiliza drivers dedicados para cada faixa de frequencia: woofer para graves (20-250Hz), driver para medios (250-4000Hz), e tweeter para agudos (4000-20000Hz). Esse sistema garante separacao de frequencias ideal e som equilibrado em qualquer volume.'
        },
        {
          title: 'Materiais Premium',
          items: [
            'Cone de polipropileno reforcado para resistencia e leveza',
            'Suspensao de borracha butilica para durabilidade',
            'Tweeter de seda para agudos suaves e detalhados',
            'Cabinete em ABS reforcado com acabamento soft-touch',
            'Grade metalica protegida contra oxidacao',
            'Conectores revestidos em ouro para melhor sinal'
          ]
        },
        {
          title: 'Experiencia Sonora',
          content: 'O resultado da combinacao de potencia real, sistema 3 vias e materiais premium e uma experiencia sonora imersiva e fiel. Seja em volumes baixos para ambientes intimos ou no maximo para festas, a qualidade se mantem consistente e prazerosa.'
        }
      ]
    },
    confianca: {
      id: 'confianca',
      name: 'Confianca',
      icon: '&#129309;',
      color: '#D4A843',
      summary: 'AIWA desde 1951, Grupo MK, garantia solida e suporte de excelencia.',
      sections: [
        {
          title: 'Historia AIWA',
          content: 'Fundada em 1951 no Japao, a AIWA construiu uma reputacao de excelencia em audio ao longo de mais de 70 anos. A marca e sinônimo de qualidade, inovacao e confiabilidade para milhoes de consumidores ao redor do mundo.'
        },
        {
          title: 'Grupo MK',
          content: 'No Brasil, a AIWA e representada pelo Grupo MK, conglomerado com decadas de experiencia no mercado de eletroeletronicos. O Grupo MK garante distribuicao nacional, suporte tecnico qualificado e reposicao de pecas em todo o territorio brasileiro.'
        },
        {
          title: 'Garantia e Suporte',
          items: [
            'Garantia de 1 ano em todos os produtos de audio',
            'Rede de assistencia tecnica autorizada em todo o Brasil',
            'Reposicao de pecas garantida por 5 anos',
            'Atendimento ao consumidor via telefone, email e WhatsApp',
            'Manual de usuario completo em portugues',
            'Video tutoriais no canal oficial AIWA Brasil'
          ]
        },
        {
          title: 'Pos-Venda',
          content: 'O relacionamento com o cliente nao termina na venda. A AIWA investe em pos-venda de qualidade, com suporte tecnico preparado, atualizacoes de firmware regulares e uma comunidade ativa de usuarios que compartilham experiencias e dicas.'
        }
      ]
    },
    inovacao: {
      id: 'inovacao',
      name: 'Inovacao',
      icon: '&#128161;',
      color: '#0A84FF',
      summary: 'Bluetooth 5.3, App, TWS, IP66, Bass Boost e tecnologias em constante evolucao.',
      sections: [
        {
          title: 'Bluetooth 5.3',
          content: 'A ultima geracao do Bluetooth oferece alcance ampliado, estabilidade superior e latencia minima. Conexao instantanea, sem quedas e com menor consumo de bateria.'
        },
        {
          title: 'App AIWA Audio BR',
          content: 'Aplicativo exclusivo que coloca o controle total na palma da mao. Equalizador grafico, presets inteligentes, controle de LED e atualizacoes de firmware direto pelo celular.'
        },
        {
          title: 'TWS',
          content: 'True Wireless Stereo permite conectar duas caixas para dobrar a potencia e criar um sistema estereo verdadeiro. Configuracao em segundos, sem fios e sem complicacao.'
        },
        {
          title: 'IP66',
          content: 'Protecao total contra poeira e jatos de agua. Use na praia, piscina, churrasco ou qualquer ambiente sem se preocupar com danos.'
        },
        {
          title: 'Bass Boost',
          content: 'Tecnologia de processamento de audio que realca os graves de forma inteligente, adicionando profundidade e impacto sem distorcer o som.'
        },
        {
          title: 'Novas Tecnologias',
          content: 'A AIWA continua investindo em P&D para trazer inovacoes constantes. Firmware atualizavel garante que sua caixa receba melhorias e novas funcoes ao longo do tempo.'
        }
      ]
    }
  },

  // ==========================================
  // SOBRE
  // ==========================================
  about: {
    aiwa: {
      title: 'A Marca AIWA',
      sections: [
        {
          title: 'Origem Japonesa',
          content: 'A AIWA foi fundada em junho de 1951 em Tokyo, Japao, por Morisaburo Tajiri. O nome AIWA significa companheiro de audio em japones, refletindo a missao da marca de acompanhar as pessoas em seus momentos atraves do som.'
        },
        {
          title: 'Linha do Tempo',
          items: [
            '1951: Fundacao da AIWA Co. Ltd. em Tokyo',
            '1964: Lancamento do primeiro radio portatil AIWA',
            '1970: Introducao do primeiro gravador de fita cassete',
            '1980: Lideranca global em walkmans e audio portatil',
            '1990: Expansao para sistemas de audio residencial',
            '2000: Integracao com tecnologias digitais',
            '2015: Relancamento global da marca AIWA',
            '2020: Entrada no mercado brasileiro com o Grupo MK',
            '2024: Expansao para TVs, ar condicionado e smart home'
          ]
        },
        {
          title: 'Grupo MK no Brasil',
          content: 'O Grupo MK e o responsavel pela distribuicao e operacao da marca AIWA no Brasil. Com infraestrutura nacional, o grupo garante que produtos AIWA cheguem a todo o territorio brasileiro com suporte tecnico e garantia local.'
        },
        {
          title: 'Portifolio Atual',
          items: [
            'Caixas de som portateis (AWS series)',
            'Soundbars para TVs',
            'Fones de ouvido wireless',
            'Smart TVs Android',
            'Ar condicionado split inverter',
            'Acessorios de audio e conectividade'
          ]
        }
      ]
    },
    promotor: {
      title: 'O Promotor',
      sections: [
        {
          title: 'Bruno Trabach',
          content: 'Promotor AIWA especializado em treinamento de equipes de vendas, demonstracoes de produtos e suporte tecnico em campo. Com experiencia pratica no varejo de eletroeletronicos, Bruno desenvolveu metodologias de atendimento que convertem curiosos em compradores.'
        },
        {
          title: 'Atividades',
          items: [
            'Treinamento de vendedores em tecnicas de vendas AIWA',
            'Demonstracoes de produtos para clientes finais',
            'Suporte tecnico e esclarecimento de duvidas',
            'Desenvolvimento de material de treinamento',
            'Acompanhamento de resultados e metas',
            'Relacionamento com lojistas e gestores'
          ]
        },
        {
          title: 'Filosofia',
          content: 'Acredito que vender e ajudar. Quando entendemos a necessidade do cliente e apresentamos a solucao certa, a venda acontece naturalmente. Meu objetivo e capacitar cada vendedor para que possa fazer isso de forma autonoma e confiante.'
        }
      ]
    },
    projeto: {
      title: 'O Projeto Playbook V2',
      sections: [
        {
          title: 'Sobre o Playbook',
          content: 'O AIWA Playbook V2 e um sistema interativo e modular desenvolvido para treinamento de vendedores, apoio a promotores e demonstracao de tecnologias. Funciona 100% offline em celulares, tablets, TVs Android e navegadores desktop.'
        },
        {
          title: 'Funcionalidades',
          items: [
            '6 modulos interativos (Historias, Comparativos, Pilares, Tecnologias, Conclusoes, Sobre)',
            '4 historias de vendas com dialogos e licoes',
            'Comparativos dinamicos de audio e ar condicionado',
            '6 tecnologias explicadas em detalhe',
            '3 pilares da marca AIWA',
            'Sistema de busca global',
            'Favoritos para acesso rapido',
            'Dicas diarias de vendas',
            'Tema claro/escuro',
            'Totalmente responsivo e offline'
          ]
        },
        {
          title: 'Evolucoes Futuras',
          items: [
            'Assistente de IA integrado para perguntas',
            'Geracao de PDFs de treinamento',
            'Player de video para demonstracoes',
            'Modo Promotor com metas e roteiros',
            'Novas categorias de produtos',
            'Analytics de uso e desempenho'
          ]
        }
      ]
    }
  },

  // ==========================================
  // QUICK ACCESS LINKS
  // ==========================================
  quickAccess: [
    { label: 'TWS', page: 'tecnologias', subpage: 'tws', icon: '&#127900;' },
    { label: 'IP66', page: 'tecnologias', subpage: 'ip66', icon: '&#128167;' },
    { label: 'Bluetooth', page: 'tecnologias', subpage: 'bluetooth', icon: '&#128246;' },
    { label: 'Bass Boost', page: 'tecnologias', subpage: 'bass-boost', icon: '&#127926;' },
    { label: 'App AIWA', page: 'tecnologias', subpage: 'app-aiwa', icon: '&#128241;' },
    { label: 'Bateria', page: 'tecnologias', subpage: 'bateria', icon: '&#128267;' },
    { label: 'Historia 1', page: 'historias', storyId: 1, icon: '&#128214;' },
    { label: 'Historia 2', page: 'historias', storyId: 2, icon: '&#128214;' },
    { label: 'Qualidade', page: 'pilares', subpage: 'qualidade', icon: '&#11088;' }
  ],

  // ==========================================
  // SEARCH INDEX
  // ==========================================
  searchIndex: function() {
    const index = [];

    // Historias
    Object.values(this.stories).forEach(story => {
      index.push({
        id: `story-${story.id}`,
        title: `Historia ${story.id}: ${story.title}`,
        desc: story.subtitle,
        category: 'Historias',
        page: 'historias',
        data: { storyId: story.id }
      });
    });

    // Tecnologias
    Object.values(this.technologies).forEach(tech => {
      index.push({
        id: `tech-${tech.id}`,
        title: tech.name,
        desc: tech.summary,
        category: 'Tecnologias',
        page: 'tecnologias',
        data: { subpage: tech.id }
      });
    });

    // Pilares
    Object.values(this.pillars).forEach(pillar => {
      index.push({
        id: `pillar-${pillar.id}`,
        title: `Pilar: ${pillar.name}`,
        desc: pillar.summary,
        category: 'Pilares',
        page: 'pilares',
        data: { subpage: pillar.id }
      });
    });

    // Comparativos
    index.push({
      id: 'compare-audio',
      title: 'Comparativo de Audio',
      desc: 'Compare caixas AIWA com JBL, LG, Philco, Mondial, Sony',
      category: 'Comparativos',
      page: 'comparativos',
      data: { subpage: 'audio' }
    });
    index.push({
      id: 'compare-ac',
      title: 'Comparativo de Ar Condicionado',
      desc: 'Compare AIWA com LG, Samsung, Electrolux, Midea, Springer',
      category: 'Comparativos',
      page: 'comparativos',
      data: { subpage: 'ar-condicionado' }
    });

    return index;
  }
};
