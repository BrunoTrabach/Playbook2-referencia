/* ============================================
   AIWA PLAYBOOK V2 - APP.JS
   Motor principal: navegacao, tema, busca,
   favoritos, dicas, renderizacao de paginas
   ============================================ */

// === ESTADO GLOBAL ===
const AppState = {
  currentPage: 'home',
  previousPage: null,
  theme: localStorage.getItem('aiwa-theme') || 'dark',
  favorites: JSON.parse(localStorage.getItem('aiwa-favorites') || '[]'),
  currentTip: parseInt(localStorage.getItem('aiwa-tip-index') || '0'),
  profileModalOpen: false,
  navigationHistory: []
};

// === INICIALIZACAO ===
document.addEventListener('DOMContentLoaded', function() {
  initTheme();
  initTips();
  initQuickAccess();
  updateDateTime();
  setInterval(updateDateTime, 1000);
  updateNavState('home');
  updateBuildDate();
});

// === THEME ===
function initTheme() {
  document.body.className = AppState.theme;
  const toggle = document.getElementById('themeToggle');
  if (toggle) {
    toggle.innerHTML = AppState.theme === 'dark' ? '\u{1F319}' : '\u{2600}';
  }
}

function toggleTheme() {
  AppState.theme = AppState.theme === 'dark' ? 'light' : 'dark';
  document.body.className = AppState.theme;
  localStorage.setItem('aiwa-theme', AppState.theme);
  const toggle = document.getElementById('themeToggle');
  if (toggle) {
    toggle.innerHTML = AppState.theme === 'dark' ? '\u{1F319}' : '\u{2600}';
  }
}

// === NAVEGACAO ===
function navigateTo(page, data = null) {
  AppState.navigationHistory.push(AppState.currentPage);
  AppState.previousPage = AppState.currentPage;
  AppState.currentPage = page;

  // Esconde todas as paginas
  document.querySelectorAll('.app-page').forEach(p => {
    p.classList.remove('active-page');
  });

  // Mostra a pagina correta
  const pageMap = {
    'home': 'page-home',
    'historias': 'page-historias',
    'comparativos': 'page-comparativos',
    'pilares': 'page-pilares',
    'tecnologias': 'page-tecnologias',
    'conclusoes': 'page-conclusoes',
    'sobre': 'page-sobre'
  };

  // Se for subpagina, renderiza conteudo dinamico
  if (page.includes('/')) {
    const [section, subpage] = page.split('/');
    renderDynamicPage(section, subpage, data);
    showPage('page-dynamic');
    updateTitle(getPageTitle(page));
  } else {
    const pageId = pageMap[page];
    if (pageId) {
      showPage(pageId);
      updateTitle(getPageTitle(page));
    }
  }

  updateNavState(page);
  updateBackButton();
  closeSearch();
  window.scrollTo(0, 0);
}

function showPage(pageId) {
  const page = document.getElementById(pageId);
  if (page) {
    page.classList.add('active-page');
  }
}

function goBack() {
  if (AppState.navigationHistory.length > 0) {
    const prev = AppState.navigationHistory.pop();
    // Remove a pagina atual do historico tambem
    if (AppState.currentPage === prev && AppState.navigationHistory.length > 0) {
      const prev2 = AppState.navigationHistory.pop();
      navigateTo(prev2 || 'home');
      return;
    }
    // Para subpaginas, volta para a secao pai
    if (AppState.currentPage.includes('/')) {
      const section = AppState.currentPage.split('/')[0];
      navigateTo(section);
      return;
    }
    navigateTo(prev || 'home');
  } else {
    navigateTo('home');
  }
}

function goToHome() {
  AppState.navigationHistory = [];
  navigateTo('home');
}

function updateBackButton() {
  const backBtn = document.getElementById('backBtn');
  if (backBtn) {
    const showBack = AppState.currentPage !== 'home';
    backBtn.style.display = showBack ? 'flex' : 'none';
  }
}

function updateTitle(title) {
  const titleEl = document.getElementById('pageTitle');
  if (titleEl) {
    titleEl.textContent = title || 'AIWA Playbook';
  }
  document.title = title ? `${title} | AIWA Playbook V2` : 'AIWA Playbook V2';
}

function getPageTitle(page) {
  const titles = {
    'home': 'Inicio',
    'historias': 'Historias',
    'comparativos': 'Comparativos',
    'pilares': '3 Pilares',
    'tecnologias': 'Tecnologias',
    'conclusoes': 'Conclusoes',
    'sobre': 'Sobre'
  };

  if (page.includes('/')) {
    const [section, sub] = page.split('/');
    return `${titles[section] || section} > ${sub}`;
  }
  return titles[page] || 'AIWA Playbook';
}

function updateNavState(page) {
  document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));

  // Mapeia subpaginas para a navegacao principal
  let navPage = page;
  if (page.includes('/')) {
    navPage = page.split('/')[0];
  }

  const navMap = {
    'home': 'nav-home',
    'historias': 'nav-historias',
    'comparativos': 'nav-comparativos',
    'tecnologias': 'nav-tecnologias',
    'sobre': 'nav-sobre'
  };

  const navId = navMap[navPage];
  if (navId) {
    const navBtn = document.getElementById(navId);
    if (navBtn) navBtn.classList.add('active');
  }
}

// === RENDERIZACAO DINAMICA ===
function renderDynamicPage(section, subpage, data) {
  const container = document.getElementById('dynamicContent');
  if (!container) return;

  let html = '';

  switch (section) {
    case 'historias':
      html = renderStoryPage(parseInt(subpage));
      break;
    case 'comparativos':
      html = renderComparisonPage(subpage);
      break;
    case 'pilares':
      html = renderPillarPage(subpage);
      break;
    case 'tecnologias':
      html = renderTechPage(subpage);
      break;
    case 'sobre':
      html = renderAboutPage(subpage);
      break;
    default:
      html = '<div class="page-hero"><h1>Em desenvolvimento</h1><p>Esta pagina sera adicionada em breve.</p></div>';
  }

  container.innerHTML = html;
}

// === HISTORIAS ===
function loadStory(storyId) {
  navigateTo(`historias/${storyId}`, { storyId });
}

function renderStoryPage(storyId) {
  const story = DB.stories[storyId];
  if (!story) return '<div class="page-hero"><h1>Historia nao encontrada</h1></div>';

  let html = `
    <div class="story-content">
      <button class="btn-back" onclick="goBack()">&#8592; Voltar</button>

      <div class="story-header">
        <h2>Historia ${story.id}: ${story.title}</h2>
        <p style="color: var(--text-secondary); margin-bottom: var(--space-sm);">${story.subtitle}</p>
        <div class="story-meta">
          <div class="story-meta-item">&#127991; ${story.tags.join(', ')}</div>
        </div>
        <div class="story-tags" style="justify-content: center; margin-top: var(--space-sm);">
          ${story.tags.map(t => `<span class="tag">${t}</span>`).join('')}
        </div>
      </div>
  `;

  story.scenes.forEach(scene => {
    html += `
      <div class="story-scene ${scene.lesson ? 'scene-highlight' : ''}">
        <div class="scene-num">Cena ${scene.num}</div>
        <div class="scene-setting">&#128205; ${scene.setting}</div>
        <div class="scene-dialogue">
    `;

    scene.lines.forEach(line => {
      if (line.action) {
        html += `<div class="dialogue-action">${line.text}</div>`;
      } else {
        html += `
          <div class="dialogue-line">
            <img src="${line.avatar}" class="dialogue-avatar" alt="${line.speaker}" onerror="this.style.display='none'">
            <div class="dialogue-bubble">
              <div class="dialogue-speaker">${line.speaker}</div>
              <div class="dialogue-text">${line.text}</div>
            </div>
          </div>
        `;
      }
    });

    html += '</div>';

    if (scene.lesson) {
      html += `
        <div class="lesson-box">
          <h4>&#127891; ${scene.lesson.title}</h4>
          <ul>
            ${scene.lesson.points.map(p => `<li>${p}</li>`).join('')}
          </ul>
        </div>
      `;
    }

    html += '</div>';
  });

  // Botao de favorito
  const isFav = isFavorite(`story-${story.id}`);
  html += `
    <div style="text-align: center; margin-top: var(--space-xl);">
      <button class="fav-btn ${isFav ? 'active' : ''}" onclick="toggleFavorite('story-${story.id}', 'Historia ${story.id}: ${story.title}', 'historias')" style="font-size: 1.5rem;">
        ${isFav ? '&#11088;' : '&#9734;'} ${isFav ? 'Favorito' : 'Adicionar aos Favoritos'}
      </button>
    </div>

    <div class="btn-group" style="justify-content: center; margin-top: var(--space-lg);">
      ${storyId > 1 ? `<button class="btn-outline" onclick="loadStory(${storyId - 1})">&#8592; Anterior</button>` : ''}
      ${storyId < 4 ? `<button class="btn-primary" onclick="loadStory(${storyId + 1})">Proxima &#8594;</button>` : ''}
    </div>
    </div>
  `;

  return html;
}

// === COMPARATIVOS ===
function renderComparisonPage(type) {
  if (type === 'audio') {
    return renderAudioComparison();
  } else if (type === 'ar-condicionado') {
    return renderACComparison();
  }
  return '<div class="page-hero"><h1>Comparativo nao encontrado</h1></div>';
}

function renderAudioComparison() {
  const aiwaProducts = DB.audioProducts.aiwa;
  const competitors = DB.audioProducts.competitors;

  let html = `
    <div class="comparison-engine">
      <button class="btn-back" onclick="goBack()">&#8592; Voltar</button>

      <div class="page-hero" style="padding-top: 0;">
        <div class="page-hero-icon">&#127897;</div>
        <h1>Comparativo de Audio</h1>
        <p>Selecione um produto AIWA e até 5 concorrentes para comparar.</p>
      </div>

      <div class="comparison-selector">
        <div class="selector-row">
          <label>AIWA:</label>
          <select id="aiwaSelect" onchange="updateAudioComparison()">
            ${aiwaProducts.map(p => `<option value="${p.id}">${p.name} - ${p.power}</option>`).join('')}
          </select>
        </div>
        <div class="selector-row">
          <label>Concorrentes:</label>
          <select id="compSelect" multiple size="5" onchange="updateAudioComparison()" style="min-height: 120px;">
            ${competitors.map(c => `<option value="${c.id}">${c.brand} ${c.name} - ${c.power}</option>`).join('')}
          </select>
        </div>
        <div class="selector-row" style="justify-content: center;">
          <button class="btn-primary" onclick="updateAudioComparison()">Atualizar Comparativo</button>
        </div>
      </div>

      <div id="audioComparisonResult"></div>
    </div>
  `;

  // Executa o update apos inserir no DOM
  setTimeout(updateAudioComparison, 100);

  return html;
}

function updateAudioComparison() {
  const aiwaId = document.getElementById('aiwaSelect')?.value;
  const compSelect = document.getElementById('compSelect');
  if (!aiwaId || !compSelect) return;

  const selectedCompIds = Array.from(compSelect.selectedOptions).map(o => o.value);
  const aiwaProduct = DB.audioProducts.aiwa.find(p => p.id === aiwaId);

  if (!aiwaProduct) return;

  const selectedComps = selectedCompIds.map(id =>
    DB.audioProducts.competitors.find(c => c.id === id)
  ).filter(Boolean);

  const allProducts = [aiwaProduct, ...selectedComps];
  const numProducts = allProducts.length;

  let html = `<div class="comparison-grid cols-${Math.min(numProducts, 5)}">`;

  allProducts.forEach(product => {
    const isAiwa = product.brand === 'AIWA';
    html += `
      <div class="compare-product-card ${isAiwa ? 'aiwa-card' : ''}">
        <div style="font-size: 2rem; margin-bottom: var(--space-sm);">&#127897;</div>
        <h4>${product.name}</h4>
        <div class="product-brand">${product.brand}</div>
        <div class="spec-row">
          <span class="spec-label">Potencia</span>
          <span class="spec-value ${isAiwa ? 'highlight' : ''}">${product.power}</span>
        </div>
        <div class="spec-row">
          <span class="spec-label">Bateria</span>
          <span class="spec-value ${isAiwa ? 'highlight' : ''}">${product.battery}</span>
        </div>
        <div class="spec-row">
          <span class="spec-label">Bluetooth</span>
          <span class="spec-value">${product.bluetooth}</span>
        </div>
        <div class="spec-row">
          <span class="spec-label">Protecao</span>
          <span class="spec-value">${product.waterResistance}</span>
        </div>
        <div class="spec-row">
          <span class="spec-label">TWS</span>
          <span class="spec-value">${product.tws ? 'Sim' : 'Nao'}</span>
        </div>
        <div class="spec-row">
          <span class="spec-label">Bass Boost</span>
          <span class="spec-value ${product.bassBoost ? 'highlight' : ''}">${product.bassBoost ? 'Sim' : 'Nao'}</span>
        </div>
        <div class="spec-row">
          <span class="spec-label">App</span>
          <span class="spec-value">${product.app ? 'Sim' : 'Nao'}</span>
        </div>
        <div class="spec-row">
          <span class="spec-label">Powerbank</span>
          <span class="spec-value ${product.powerbank ? 'highlight' : ''}">${product.powerbank ? 'Sim' : 'Nao'}</span>
        </div>
        <div class="spec-row">
          <span class="spec-label">Peso</span>
          <span class="spec-value">${product.weight}</span>
        </div>
        <div class="spec-row">
          <span class="spec-label">Preco</span>
          <span class="spec-value ${isAiwa ? 'highlight' : ''}">${product.price}</span>
        </div>
        ${isAiwa ? '<div class="winner-badge">MELHOR CUSTO-BENEFICIO</div>' : ''}
      </div>
    `;
  });

  html += '</div>';

  // Tabela comparativa
  if (numProducts > 1) {
    html += `
      <div class="tech-section" style="margin-top: var(--space-xl);">
        <h3>&#128202; Resumo Comparativo</h3>
        <div style="overflow-x: auto;">
          <table style="width: 100%; border-collapse: collapse; font-size: 0.85rem;">
            <thead>
              <tr style="border-bottom: 2px solid var(--accent);">
                <th style="padding: var(--space-sm); text-align: left; color: var(--text-muted);">Especificacao</th>
                ${allProducts.map(p => `<th style="padding: var(--space-sm); text-align: center; color: ${p.brand === 'AIWA' ? 'var(--accent)' : 'var(--text-primary)'};">${p.brand}<br><small>${p.name}</small></th>`).join('')}
              </tr>
            </thead>
            <tbody>
              <tr style="border-bottom: 1px solid var(--border);">
                <td style="padding: var(--space-sm); color: var(--text-muted);">Potencia</td>
                ${allProducts.map(p => `<td style="padding: var(--space-sm); text-align: center; font-weight: ${p.brand === 'AIWA' ? '700' : '400'}; color: ${p.brand === 'AIWA' ? 'var(--accent)' : 'var(--text-primary)'};">${p.power}</td>`).join('')}
              </tr>
              <tr style="border-bottom: 1px solid var(--border);">
                <td style="padding: var(--space-sm); color: var(--text-muted);">Bateria</td>
                ${allProducts.map(p => `<td style="padding: var(--space-sm); text-align: center; font-weight: ${p.brand === 'AIWA' ? '700' : '400'}; color: ${p.brand === 'AIWA' ? 'var(--accent)' : 'var(--text-primary)'};">${p.battery}</td>`).join('')}
              </tr>
              <tr style="border-bottom: 1px solid var(--border);">
                <td style="padding: var(--space-sm); color: var(--text-muted);">Bluetooth</td>
                ${allProducts.map(p => `<td style="padding: var(--space-sm); text-align: center;">${p.bluetooth}</td>`).join('')}
              </tr>
              <tr style="border-bottom: 1px solid var(--border);">
                <td style="padding: var(--space-sm); color: var(--text-muted);">Bass Boost</td>
                ${allProducts.map(p => `<td style="padding: var(--space-sm); text-align: center; color: ${p.bassBoost ? 'var(--success)' : 'var(--text-muted)'};">${p.bassBoost ? '&#10003;' : '&#10007;'}</td>`).join('')}
              </tr>
              <tr style="border-bottom: 1px solid var(--border);">
                <td style="padding: var(--space-sm); color: var(--text-muted);">App</td>
                ${allProducts.map(p => `<td style="padding: var(--space-sm); text-align: center; color: ${p.app ? 'var(--success)' : 'var(--text-muted)'};">${p.app ? '&#10003;' : '&#10007;'}</td>`).join('')}
              </tr>
              <tr style="border-bottom: 1px solid var(--border);">
                <td style="padding: var(--space-sm); color: var(--text-muted);">Powerbank</td>
                ${allProducts.map(p => `<td style="padding: var(--space-sm); text-align: center; color: ${p.powerbank ? 'var(--success)' : 'var(--text-muted)'};">${p.powerbank ? '&#10003;' : '&#10007;'}</td>`).join('')}
              </tr>
              <tr>
                <td style="padding: var(--space-sm); color: var(--text-muted);">Preco</td>
                ${allProducts.map(p => `<td style="padding: var(--space-sm); text-align: center; font-weight: 700; color: ${p.brand === 'AIWA' ? 'var(--accent)' : 'var(--text-primary)'};">${p.price}</td>`).join('')}
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    `;
  }

  const resultEl = document.getElementById('audioComparisonResult');
  if (resultEl) resultEl.innerHTML = html;
}

function renderACComparison() {
  const aiwaProducts = DB.acProducts.aiwa;
  const competitors = DB.acProducts.competitors;

  return `
    <div class="comparison-engine">
      <button class="btn-back" onclick="goBack()">&#8592; Voltar</button>

      <div class="page-hero" style="padding-top: 0;">
        <div class="page-hero-icon">&#10052;</div>
        <h1>Comparativo de Ar Condicionado</h1>
        <p>Selecione um produto AIWA e concorrentes para comparar.</p>
      </div>

      <div class="comparison-selector">
        <div class="selector-row">
          <label>AIWA:</label>
          <select id="acAiwaSelect" onchange="updateACComparison()">
            ${aiwaProducts.map(p => `<option value="${p.id}">${p.name} - ${p.btu} BTU</option>`).join('')}
          </select>
        </div>
        <div class="selector-row">
          <label>Concorrentes:</label>
          <select id="acCompSelect" multiple size="5" onchange="updateACComparison()" style="min-height: 120px;">
            ${competitors.map(c => `<option value="${c.id}">${c.brand} ${c.name}</option>`).join('')}
          </select>
        </div>
        <div class="selector-row" style="justify-content: center;">
          <button class="btn-primary" onclick="updateACComparison()">Atualizar Comparativo</button>
        </div>
      </div>

      <div id="acComparisonResult"></div>
    </div>
  `;
}

function updateACComparison() {
  const aiwaId = document.getElementById('acAiwaSelect')?.value;
  const compSelect = document.getElementById('acCompSelect');
  if (!aiwaId || !compSelect) return;

  const selectedCompIds = Array.from(compSelect.selectedOptions).map(o => o.value);
  const aiwaProduct = DB.acProducts.aiwa.find(p => p.id === aiwaId);
  if (!aiwaProduct) return;

  const selectedComps = selectedCompIds.map(id =>
    DB.acProducts.competitors.find(c => c.id === id)
  ).filter(Boolean);

  const allProducts = [aiwaProduct, ...selectedComps];
  const numProducts = allProducts.length;

  let html = `<div class="comparison-grid cols-${Math.min(numProducts, 5)}">`;

  allProducts.forEach(product => {
    const isAiwa = product.brand === 'AIWA';
    html += `
      <div class="compare-product-card ${isAiwa ? 'aiwa-card' : ''}">
        <div style="font-size: 2rem; margin-bottom: var(--space-sm);">&#10052;</div>
        <h4>${product.name}</h4>
        <div class="product-brand">${product.brand}</div>
        <div class="spec-row">
          <span class="spec-label">BTU</span>
          <span class="spec-value ${isAiwa ? 'highlight' : ''}">${product.btu}</span>
        </div>
        <div class="spec-row">
          <span class="spec-label">Inverter</span>
          <span class="spec-value ${product.inverter ? 'highlight' : ''}">${product.inverter ? 'Sim' : 'Nao'}</span>
        </div>
        <div class="spec-row">
          <span class="spec-label">Eficiencia</span>
          <span class="spec-value ${isAiwa ? 'highlight' : ''}">${product.energyClass}</span>
        </div>
        <div class="spec-row">
          <span class="spec-label">WiFi</span>
          <span class="spec-value">${product.wifi ? 'Sim' : 'Nao'}</span>
        </div>
        <div class="spec-row">
          <span class="spec-label">App</span>
          <span class="spec-value">${product.app ? 'Sim' : 'Nao'}</span>
        </div>
        <div class="spec-row">
          <span class="spec-label">Silencio</span>
          <span class="spec-value ${isAiwa ? 'highlight' : ''}">${product.silent}</span>
        </div>
        <div class="spec-row">
          <span class="spec-label">Filtro</span>
          <span class="spec-value">${product.filter}</span>
        </div>
        <div class="spec-row">
          <span class="spec-label">Gas</span>
          <span class="spec-value ${product.gas === 'R-32' ? 'highlight' : ''}">${product.gas}</span>
        </div>
        <div class="spec-row">
          <span class="spec-label">Garantia</span>
          <span class="spec-value">${product.warranty}</span>
        </div>
        <div class="spec-row">
          <span class="spec-label">Preco</span>
          <span class="spec-value ${isAiwa ? 'highlight' : ''}">${product.price}</span>
        </div>
        ${isAiwa ? '<div class="winner-badge">MELHOR CUSTO-BENEFICIO</div>' : ''}
      </div>
    `;
  });

  html += '</div>';

  if (numProducts > 1) {
    html += `
      <div class="tech-section" style="margin-top: var(--space-xl);">
        <h3>&#128202; Resumo Comparativo</h3>
        <div style="overflow-x: auto;">
          <table style="width: 100%; border-collapse: collapse; font-size: 0.85rem;">
            <thead>
              <tr style="border-bottom: 2px solid var(--accent);">
                <th style="padding: var(--space-sm); text-align: left; color: var(--text-muted);">Especificacao</th>
                ${allProducts.map(p => `<th style="padding: var(--space-sm); text-align: center; color: ${p.brand === 'AIWA' ? 'var(--accent)' : 'var(--text-primary)'};">${p.brand}<br><small>${p.name}</small></th>`).join('')}
              </tr>
            </thead>
            <tbody>
              <tr style="border-bottom: 1px solid var(--border);">
                <td style="padding: var(--space-sm); color: var(--text-muted);">Inverter</td>
                ${allProducts.map(p => `<td style="padding: var(--space-sm); text-align: center; color: ${p.inverter ? 'var(--success)' : 'var(--text-muted)'};">${p.inverter ? '&#10003;' : '&#10007;'}</td>`).join('')}
              </tr>
              <tr style="border-bottom: 1px solid var(--border);">
                <td style="padding: var(--space-sm); color: var(--text-muted);">Eficiencia</td>
                ${allProducts.map(p => `<td style="padding: var(--space-sm); text-align: center; font-weight: ${p.brand === 'AIWA' ? '700' : '400'};">${p.energyClass}</td>`).join('')}
              </tr>
              <tr style="border-bottom: 1px solid var(--border);">
                <td style="padding: var(--space-sm); color: var(--text-muted);">WiFi/App</td>
                ${allProducts.map(p => `<td style="padding: var(--space-sm); text-align: center; color: ${p.wifi ? 'var(--success)' : 'var(--text-muted)'};">${p.wifi ? '&#10003;' : '&#10007;'}</td>`).join('')}
              </tr>
              <tr style="border-bottom: 1px solid var(--border);">
                <td style="padding: var(--space-sm); color: var(--text-muted);">Gas R-32</td>
                ${allProducts.map(p => `<td style="padding: var(--space-sm); text-align: center; color: ${p.gas === 'R-32' ? 'var(--success)' : 'var(--warning)'};">${p.gas}</td>`).join('')}
              </tr>
              <tr>
                <td style="padding: var(--space-sm); color: var(--text-muted);">Preco</td>
                ${allProducts.map(p => `<td style="padding: var(--space-sm); text-align: center; font-weight: 700; color: ${p.brand === 'AIWA' ? 'var(--accent)' : 'var(--text-primary)'};">${p.price}</td>`).join('')}
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    `;
  }

  const resultEl = document.getElementById('acComparisonResult');
  if (resultEl) resultEl.innerHTML = html;
}

// === PILARES ===
function renderPillarPage(pillarId) {
  const pillar = DB.pillars[pillarId];
  if (!pillar) return '<div class="page-hero"><h1>Pilar nao encontrado</h1></div>';

  let html = `
    <div class="tech-page">
      <button class="btn-back" onclick="goBack()">&#8592; Voltar</button>

      <div class="tech-header">
        <div class="tech-header-icon" style="color: ${pillar.color};">${pillar.icon}</div>
        <h2>${pillar.name}</h2>
        <p>${pillar.summary}</p>
      </div>
  `;

  pillar.sections.forEach(section => {
    html += `
      <div class="tech-section">
        <h3><span class="section-icon">&#128204;</span> ${section.title}</h3>
    `;

    if (section.content) {
      html += `<p>${section.content}</p>`;
    }

    if (section.items) {
      html += '<ul>';
      section.items.forEach(item => {
        html += `<li>${item}</li>`;
      });
      html += '</ul>';
    }

    html += '</div>';
  });

  const isFav = isFavorite(`pillar-${pillar.id}`);
  html += `
    <div style="text-align: center; margin-top: var(--space-xl);">
      <button class="fav-btn ${isFav ? 'active' : ''}" onclick="toggleFavorite('pillar-${pillar.id}', 'Pilar: ${pillar.name}', 'pilares')" style="font-size: 1.3rem;">
        ${isFav ? '&#11088;' : '&#9734;'} ${isFav ? 'Favorito' : 'Adicionar aos Favoritos'}
      </button>
    </div>
    </div>
  `;

  return html;
}

// === TECNOLOGIAS ===
function renderTechPage(techId) {
  const tech = DB.technologies[techId];
  if (!tech) return '<div class="page-hero"><h1>Tecnologia nao encontrada</h1></div>';

  let html = `
    <div class="tech-page">
      <button class="btn-back" onclick="goBack()">&#8592; Voltar</button>

      <div class="tech-header">
        <div class="tech-header-icon">${tech.icon}</div>
        <h2>${tech.name}</h2>
        <p>${tech.summary}</p>
        <span class="tech-badge">${tech.category}</span>
      </div>
  `;

  tech.sections.forEach(section => {
    html += `
      <div class="tech-section">
        <h3><span class="section-icon">${section.icon || '&#128204;'}</span> ${section.title}</h3>
    `;

    if (section.content) {
      html += `<p>${section.content}</p>`;
    }

    if (section.items) {
      html += '<ul>';
      section.items.forEach(item => {
        html += `<li>${item}</li>`;
      });
      html += '</ul>';
    }

    // Comparacao dentro da tecnologia (ex: Bluetooth)
    if (section.comparison) {
      html += `
        <div style="overflow-x: auto; margin-top: var(--space-md);">
          <table style="width: 100%; border-collapse: collapse; font-size: 0.82rem;">
            <thead>
              <tr style="border-bottom: 2px solid var(--accent);">
      `;

      const headers = Object.keys(section.comparison[0]);
      headers.forEach(h => {
        const label = h === 'spec' ? 'Especificacao' : h === 'level' ? 'Nivel' : h === 'v53' ? 'BT 5.3' : h === 'v52' ? 'BT 5.2' : h === 'v42' ? 'BT 4.2' : h;
        html += `<th style="padding: var(--space-sm); text-align: ${h === 'spec' || h === 'level' || h === 'aspect' ? 'left' : 'center'}; color: var(--text-muted);">${label}</th>`;
      });

      html += '</tr></thead><tbody>';

      section.comparison.forEach(row => {
        html += '<tr style="border-bottom: 1px solid var(--border);">';
        headers.forEach((h, i) => {
          const isFirst = i === 0;
          const val = row[h];
          const isHighlight = val === 'Sim' || val === 'Total' || val === 'Excelente' || val === 'Minimo' || val === '10m+' || val === 'Baixissima' || val === 'A+++' || val === 'Sim' || val === 'R-32';
          html += `<td style="padding: var(--space-sm); text-align: ${isFirst ? 'left' : 'center'}; color: ${isHighlight && !isFirst ? 'var(--success)' : isFirst ? 'var(--text-muted)' : 'var(--text-primary)'}; font-weight: ${isHighlight && !isFirst ? '700' : '400'};">${val}</td>`;
        });
        html += '</tr>';
      });

      html += '</tbody></table></div>';
    }

    html += '</div>';
  });

  const isFav = isFavorite(`tech-${tech.id}`);
  html += `
    <div style="text-align: center; margin-top: var(--space-xl);">
      <button class="fav-btn ${isFav ? 'active' : ''}" onclick="toggleFavorite('tech-${tech.id}', '${tech.name}', 'tecnologias')" style="font-size: 1.3rem;">
        ${isFav ? '&#11088;' : '&#9734;'} ${isFav ? 'Favorito' : 'Adicionar aos Favoritos'}
      </button>
    </div>
    </div>
  `;

  return html;
}

// === SOBRE ===
function renderAboutPage(subpage) {
  const about = DB.about[subpage];
  if (!about) return '<div class="page-hero"><h1>Secao nao encontrada</h1></div>';

  let html = `
    <div class="about-detail">
      <button class="btn-back" onclick="goBack()">&#8592; Voltar</button>
      <h2>${about.title}</h2>
  `;

  about.sections.forEach(section => {
    html += `<h3>${section.title}</h3>`;

    if (section.content) {
      html += `<p>${section.content}</p>`;
    }

    if (section.items) {
      // Verifica se e a timeline
      if (section.title === 'Linha do Tempo') {
        html += '<div class="timeline">';
        section.items.forEach(item => {
          const [year, ...textParts] = item.split(':');
          html += `
            <div class="timeline-item">
              <div class="timeline-year">${year.trim()}</div>
              <div class="timeline-text">${textParts.join(':').trim()}</div>
            </div>
          `;
        });
        html += '</div>';
      } else {
        html += '<ul>';
        section.items.forEach(item => {
          html += `<li>${item}</li>`;
        });
        html += '</ul>';
      }
    }
  });

  html += '</div>';
  return html;
}

// === PROFILE MODAL ===
function showProfile(profileId) {
  const profile = DB.profiles[profileId];
  if (!profile) return;

  let existingModal = document.querySelector('.profile-modal');
  if (existingModal) existingModal.remove();

  const modal = document.createElement('div');
  modal.className = 'profile-modal';
  modal.innerHTML = `
    <div class="profile-modal-content">
      <img src="${profile.avatar}" class="profile-modal-avatar" alt="${profile.name}" onerror="this.style.display='none'">
      <h3>${profile.name}</h3>
      <div class="profile-role">${profile.role}</div>
      <p>${profile.bio}</p>
      ${profile.skills ? `
        <div style="display: flex; flex-wrap: wrap; gap: var(--space-xs); justify-content: center; margin-bottom: var(--space-lg);">
          ${profile.skills.map(s => `<span class="tag">${s}</span>`).join('')}
        </div>
      ` : ''}
      ${profile.tags ? `
        <div style="display: flex; flex-wrap: wrap; gap: var(--space-xs); justify-content: center; margin-bottom: var(--space-lg);">
          ${profile.tags.map(t => `<span class="tag pillar">${t}</span>`).join('')}
        </div>
      ` : ''}
      <button class="profile-modal-close" onclick="closeProfileModal()">Fechar</button>
    </div>
  `;

  modal.addEventListener('click', function(e) {
    if (e.target === modal) closeProfileModal();
  });

  document.body.appendChild(modal);
  requestAnimationFrame(() => modal.classList.add('active'));
  AppState.profileModalOpen = true;
}

function closeProfileModal() {
  const modal = document.querySelector('.profile-modal');
  if (modal) {
    modal.classList.remove('active');
    setTimeout(() => {
      modal.remove();
      AppState.profileModalOpen = false;
    }, 300);
  }
}

// === DICAS ===
function initTips() {
  renderTip();
  renderTipDots();
}

function renderTip() {
  const tip = DB.tips[AppState.currentTip];
  const tipEl = document.getElementById('tipDescText');
  if (tipEl && tip) {
    tipEl.textContent = tip.text;
  }
}

function renderTipDots() {
  const dotsContainer = document.getElementById('tipDots');
  if (!dotsContainer) return;

  let html = '';
  DB.tips.forEach((_, i) => {
    html += `<span class="dot ${i === AppState.currentTip ? 'active' : ''}" onclick="goToTip(${i})"></span>`;
  });
  dotsContainer.innerHTML = html;
}

function nextTip() {
  AppState.currentTip = (AppState.currentTip + 1) % DB.tips.length;
  localStorage.setItem('aiwa-tip-index', AppState.currentTip);
  renderTip();
  renderTipDots();
}

function goToTip(index) {
  AppState.currentTip = index;
  localStorage.setItem('aiwa-tip-index', AppState.currentTip);
  renderTip();
  renderTipDots();
}

// === QUICK ACCESS ===
function initQuickAccess() {
  const container = document.getElementById('quickChips');
  if (!container) return;

  let html = '';
  DB.quickAccess.forEach(item => {
    html += `
      <div class="quick-chip" onclick="navigateQuick('${item.page}', '${item.subpage || ''}', ${item.storyId || 'null'})">
        <span>${item.icon}</span>
        <span>${item.label}</span>
      </div>
    `;
  });
  container.innerHTML = html;
}

function navigateQuick(page, subpage, storyId) {
  if (storyId) {
    loadStory(storyId);
  } else if (subpage) {
    navigateTo(`${page}/${subpage}`);
  } else {
    navigateTo(page);
  }
}

// === FAVORITOS ===
function isFavorite(id) {
  return AppState.favorites.some(f => f.id === id);
}

function toggleFavorite(id, title, category) {
  const index = AppState.favorites.findIndex(f => f.id === id);

  if (index >= 0) {
    AppState.favorites.splice(index, 1);
  } else {
    AppState.favorites.push({ id, title, category, date: new Date().toISOString() });
  }

  localStorage.setItem('aiwa-favorites', JSON.stringify(AppState.favorites));

  // Re-renderiza o botao
  const btn = document.querySelector(`button[onclick*="'${id}'"]`);
  if (btn) {
    const isFav = isFavorite(id);
    btn.innerHTML = `${isFav ? '&#11088;' : '&#9734;'} ${isFav ? 'Favorito' : 'Adicionar aos Favoritos'}`;
    btn.classList.toggle('active', isFav);
  }
}

function showFavorites() {
  const container = document.getElementById('dynamicContent');
  if (!container) return;

  document.querySelectorAll('.app-page').forEach(p => p.classList.remove('active-page'));
  document.getElementById('page-dynamic').classList.add('active-page');

  let html = `
    <div class="page-hero">
      <div class="page-hero-icon">&#11088;</div>
      <h1>Meus Favoritos</h1>
      <p>Itens salvos para acesso rapido.</p>
    </div>
  `;

  if (AppState.favorites.length === 0) {
    html += `
      <div class="empty-state">
        <div class="empty-state-icon">&#9734;</div>
        <p>Nenhum favorito ainda.</p>
        <p style="font-size: 0.85rem; margin-top: var(--space-sm);">Toque na estrela em qualquer pagina para adicionar aos favoritos.</p>
      </div>
    `;
  } else {
    html += '<div class="favorites-list">';
    AppState.favorites.forEach(fav => {
      const pageRoute = fav.id.startsWith('story-')
        ? `historias/${fav.id.replace('story-', '')}`
        : fav.id.startsWith('tech-')
        ? `tecnologias/${fav.id.replace('tech-', '')}`
        : fav.id.startsWith('pillar-')
        ? `pilares/${fav.id.replace('pillar-', '')}`
        : 'home';

      html += `
        <div class="fav-item" onclick="navigateTo('${pageRoute}')">
          <div class="fav-icon">${fav.id.startsWith('story-') ? '&#128214;' : fav.id.startsWith('tech-') ? '&#9889;' : '&#128737;'}</div>
          <div class="fav-info">
            <div class="fav-title">${fav.title}</div>
            <div class="fav-cat">${fav.category}</div>
          </div>
          <button class="fav-remove" onclick="event.stopPropagation(); removeFavorite('${fav.id}')">&#10005;</button>
        </div>
      `;
    });
    html += '</div>';
  }

  html += `
    <div style="text-align: center; margin-top: var(--space-xl);">
      <button class="btn-outline" onclick="goBack()">Voltar</button>
    </div>
  `;

  container.innerHTML = html;
  updateTitle('Favoritos');
  updateBackButton();
}

function removeFavorite(id) {
  const index = AppState.favorites.findIndex(f => f.id === id);
  if (index >= 0) {
    AppState.favorites.splice(index, 1);
    localStorage.setItem('aiwa-favorites', JSON.stringify(AppState.favorites));
    showFavorites();
  }
}

// === BUSCA ===
function toggleSearch() {
  const searchBar = document.getElementById('searchBar');
  const searchResults = document.getElementById('searchResults');

  if (searchBar.style.display === 'none' || !searchBar.style.display) {
    searchBar.style.display = 'flex';
    searchResults.style.display = 'none';
    document.getElementById('searchInput').focus();
  } else {
    closeSearch();
  }
}

function closeSearch() {
  const searchBar = document.getElementById('searchBar');
  const searchResults = document.getElementById('searchResults');
  if (searchBar) {
    searchBar.style.display = 'none';
    document.getElementById('searchInput').value = '';
  }
  if (searchResults) searchResults.style.display = 'none';
}

function performSearch(query) {
  const resultsContainer = document.getElementById('searchResults');

  if (!query || query.length < 2) {
    resultsContainer.style.display = 'none';
    return;
  }

  const index = DB.searchIndex();
  const lowerQuery = query.toLowerCase();

  const results = index.filter(item =>
    item.title.toLowerCase().includes(lowerQuery) ||
    item.desc.toLowerCase().includes(lowerQuery) ||
    item.category.toLowerCase().includes(lowerQuery)
  );

  if (results.length === 0) {
    resultsContainer.innerHTML = '<div style="padding: var(--space-md); color: var(--text-muted); text-align: center;">Nenhum resultado encontrado.</div>';
    resultsContainer.style.display = 'block';
    return;
  }

  let html = '';
  results.forEach(r => {
    const icon = r.category === 'Historias' ? '&#128214;' : r.category === 'Tecnologias' ? '&#9889;' : r.category === 'Pilares' ? '&#128737;' : '&#128202;';
    html += `
      <div class="search-result-item" onclick="executeSearchResult('${r.page}', ${JSON.stringify(r.data).replace(/"/g, '&quot;'})">
        <div class="result-icon">${icon}</div>
        <div class="result-info">
          <div class="result-title">${r.title}</div>
          <div class="result-desc">${r.desc}</div>
        </div>
        <div class="result-cat">${r.category}</div>
      </div>
    `;
  });

  resultsContainer.innerHTML = html;
  resultsContainer.style.display = 'block';
}

function executeSearchResult(page, data) {
  closeSearch();

  if (data && data.storyId) {
    loadStory(data.storyId);
  } else if (data && data.subpage) {
    navigateTo(`${page}/${data.subpage}`);
  } else {
    navigateTo(page);
  }
}

// === UTILIDADES ===
function updateDateTime() {
  const el = document.getElementById('datetime');
  if (!el) return;

  const now = new Date();
  const options = {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  };
  el.textContent = now.toLocaleDateString('pt-BR', options);
}

function updateBuildDate() {
  const el = document.getElementById('buildDate');
  if (el) {
    el.textContent = 'Build: ' + new Date().toLocaleDateString('pt-BR');
  }
}

function fallbackAvatar(img) {
  img.style.display = 'none';
  const fallback = document.createElement('div');
  fallback.style.cssText = 'width:64px;height:64px;border-radius:50%;background:var(--bg-elevated);display:flex;align-items:center;justify-content:center;color:var(--text-muted);font-size:1.5rem;';
  fallback.innerHTML = '&#128100;';
  img.parentNode.insertBefore(fallback, img);
}

// === KEYBOARD SHORTCUTS ===
document.addEventListener('keydown', function(e) {
  // ESC fecha modais e busca
  if (e.key === 'Escape') {
    closeProfileModal();
    closeSearch();
  }

  // / abre busca
  if (e.key === '/' && document.activeElement.tagName !== 'INPUT') {
    e.preventDefault();
    toggleSearch();
  }

  // Alt + numero navega
  if (e.altKey && e.key >= '1' && e.key <= '5') {
    const pages = ['home', 'historias', 'comparativos', 'tecnologias', 'sobre'];
    const idx = parseInt(e.key) - 1;
    if (pages[idx]) navigateTo(pages[idx]);
  }
});

// === GESTOS SWIPE ===
let touchStartX = 0;
let touchEndX = 0;

document.addEventListener('touchstart', function(e) {
  touchStartX = e.changedTouches[0].screenX;
}, false);

document.addEventListener('touchend', function(e) {
  touchEndX = e.changedTouches[0].screenX;
  handleSwipe();
}, false);

function handleSwipe() {
  const swipeThreshold = 100;
  const diff = touchEndX - touchStartX;

  if (Math.abs(diff) > swipeThreshold) {
    if (diff > 0) {
      // Swipe direita - volta
      if (AppState.currentPage !== 'home') goBack();
    }
    // Swipe esquerda - poderia avancar em certos contextos
  }
}
