
const CACHE='playbook-v4';
const ASSETS=['./','./index.html','./sobre.html','./tecnologias.html','./assets/tailwind.css','./manifest.json'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)))});
self.addEventListener('fetch',e=>{e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request)))});
