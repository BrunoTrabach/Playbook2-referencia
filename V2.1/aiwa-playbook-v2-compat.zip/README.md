# AIWA Playbook V2 — Pacote de Compatibilidade

## 📦 O que mudou

Este pacote corrige a compatibilidade entre o CSS original e as novas funcionalidades.

## 🚀 Como aplicar no Termux

```bash
cd ~/aiwa-playbook-v2

# 1. Restaurar CSS original do backup
cp ~/aiwa-playbook-v2-backup-20260622-213734/css/style.css ./css/style.css

# 2. Copiar o complemento mínimo
cp /sdcard/Download/complemento-minimo.css ./css/complemento-minimo.css

# 3. Adicionar no final do style.css
cat css/complemento-minimo.css >> css/style.css

# 4. Substituir index.html pelo compatível
cp /sdcard/Download/index-compat.html ./index.html

# 5. Subir
git add .
git commit -m "V2.1.4 — CSS original + complemento mínimo + HTML compatível"
git push origin main
```

## ✅ O que vai funcionar

- Menu com 7 cards estilizados (com seu tema neon)
- Header com logo AIWA
- Abas em Histórias e Tecnologias
- Chat de histórias com avatares
- Assistente AIWA com sugestões
- Navegação inferior
- Tema dark/light
