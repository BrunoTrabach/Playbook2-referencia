# AIWA Playbook V2 — Pacote de Atualização

## 📦 O que está neste pacote

| Arquivo | Descrição |
|---------|-----------|
| `js/database.js` | Dados completos: produtos, pilares, comparativos, conclusões, assistente AIWA |
| `js/app.js` | Engine atualizada com carregador de tecnologias e assistente |
| `sw.js` | Service Worker com cache de TODOS os módulos |
| `components/assistente.html` | Interface do Assistente AIWA offline |
| `components/tecnologias/` | 6 arquivos: bluetooth, tws, ip66, app_aiwa, bass_boost, bateria |
| `update-playbook.sh` | Script automático para o Termux |

## 🚀 Como instalar no Termux

### Opção 1 — Script automático (recomendado)

```bash
# 1. Descompacte este pacote na pasta home
cd ~
unzip aiwa-playbook-v2-update.zip -d playbook-update

# 2. Dê permissão e execute o script
chmod +x playbook-update/update-playbook.sh
./playbook-update/update-playbook.sh
```

### Opção 2 — Manual

```bash
# 1. Faça backup
cp -r ~/aiwa-playbook-v2 ~/aiwa-playbook-v2-backup

# 2. Copie os arquivos novos
cp playbook-update/js/database.js ~/aiwa-playbook-v2/js/
cp playbook-update/js/app.js ~/aiwa-playbook-v2/js/
cp playbook-update/sw.js ~/aiwa-playbook-v2/
cp playbook-update/components/assistente.html ~/aiwa-playbook-v2/components/
cp playbook-update/components/tecnologias/* ~/aiwa-playbook-v2/components/tecnologias/

# 3. Renomeie avatares (se ainda não fez)
cd ~/aiwa-playbook-v2/assets/avatares
mv Bruno_Promotor_Aiwa.jpg bruno.jpg 2>/dev/null
mv Cristiane_cliente.jpg cristiane.jpg 2>/dev/null
mv Edy_Vendedor.jpg edy.jpg 2>/dev/null
mv Fernanda_amiga.jpg fernanda.jpg 2>/dev/null

# 4. Atualize referências nas histórias
sed -i 's|Bruno_Promotor_Aiwa.jpg|bruno.jpg|g' ~/aiwa-playbook-v2/components/historias/*.html
sed -i 's|Cristiane_cliente.jpg|cristiane.jpg|g' ~/aiwa-playbook-v2/components/historias/*.html
sed -i 's|Edy_Vendedor.jpg|edy.jpg|g' ~/aiwa-playbook-v2/components/historias/*.html
sed -i 's|Fernanda_amiga.jpg|fernanda.jpg|g' ~/aiwa-playbook-v2/components/historias/*.html
```

## ✅ Checklist pós-instalação

- [ ] `js/database.js` tem 27KB+
- [ ] `components/tecnologias/` tem 6 arquivos
- [ ] `components/assistente.html` existe
- [ ] Avatares renomeados para `bruno.jpg`, `cristiane.jpg`, `edy.jpg`, `fernanda.jpg`
- [ ] Histórias apontam para os novos nomes de avatar
- [ ] `git status` mostra as mudanças
- [ ] Testou no navegador com `termux-open index.html`

## 🔥 Próximos passos

Quando quiser ativar o Firebase (login, ranking, nuvem), é só criar o projeto em console.firebase.google.com e colar as credenciais no `js/database.js`.

---
**AIWA Playbook V2** — Japanese Technology Since 1951
