#!/bin/bash
# ========================================
# AIWA PLAYBOOK V2 — Script de Atualização
# Execute dentro do ~/aiwa-playbook-v2/
# ========================================

echo "🚀 Iniciando atualização do AIWA Playbook V2..."

# 1. Backup
BACKUP_DIR="$HOME/aiwa-playbook-v2-backup-$(date +%Y%m%d-%H%M%S)"
echo "📦 Criando backup em: $BACKUP_DIR"
cp -r "$HOME/aiwa-playbook-v2" "$BACKUP_DIR"

# 2. Entrar no diretório
cd "$HOME/aiwa-playbook-v2" || exit 1

# 3. Criar pastas necessárias
echo "📁 Criando estrutura de pastas..."
mkdir -p components/tecnologias
mkdir -p assets/avatares
mkdir -p assets/logos
mkdir -p js
mkdir -p core
mkdir -p css

# 4. Renomear avatares (se existirem com nomes antigos)
echo "🖼️ Renomeando avatares..."
[ -f "assets/avatares/Bruno_Promotor_Aiwa.jpg" ] && mv "assets/avatares/Bruno_Promotor_Aiwa.jpg" "assets/avatares/bruno.jpg"
[ -f "assets/avatares/Cristiane_cliente.jpg" ] && mv "assets/avatares/Cristiane_cliente.jpg" "assets/avatares/cristiane.jpg"
[ -f "assets/avatares/Edy_Vendedor.jpg" ] && mv "assets/avatares/Edy_Vendedor.jpg" "assets/avatares/edy.jpg"
[ -f "assets/avatares/Fernanda_amiga.jpg" ] && mv "assets/avatares/Fernanda_amiga.jpg" "assets/avatares/fernanda.jpg"

# 5. Atualizar referências nos arquivos de história
echo "📝 Atualizando referências de avatares nas histórias..."
if [ -d "components/historias" ]; then
  for file in components/historias/hist*.html components/historias/hist_expandida.html; do
    [ -f "$file" ] || continue
    sed -i 's|assets/avatares/Bruno_Promotor_Aiwa.jpg|assets/avatares/bruno.jpg|g' "$file"
    sed -i 's|assets/avatares/Cristiane_cliente.jpg|assets/avatares/cristiane.jpg|g' "$file"
    sed -i 's|assets/avatares/Edy_Vendedor.jpg|assets/avatares/edy.jpg|g' "$file"
    sed -i 's|assets/avatares/Fernanda_amiga.jpg|assets/avatares/fernanda.jpg|g' "$file"
  done
fi

# 6. Copiar novos arquivos (assumindo que você descompactou o update na pasta ~/playbook-update/)
UPDATE_DIR="$HOME/playbook-update"
if [ -d "$UPDATE_DIR" ]; then
  echo "📥 Copiando novos arquivos..."
  cp -f "$UPDATE_DIR/js/database.js" js/database.js
  cp -f "$UPDATE_DIR/js/app.js" js/app.js
  cp -f "$UPDATE_DIR/sw.js" sw.js
  cp -f "$UPDATE_DIR/components/assistente.html" components/assistente.html
  cp -f "$UPDATE_DIR/components/tecnologias/"* components/tecnologias/
else
  echo "⚠️  Atenção: Pasta $UPDATE_DIR não encontrada."
  echo "   Descompacte o pacote de atualização em ~/playbook-update primeiro."
fi

# 7. Permissões
chmod -R 755 .

echo ""
echo "✅ Atualização concluída!"
echo "📂 Backup salvo em: $BACKUP_DIR"
echo ""
echo "Próximos passos:"
echo "1. Verifique se tudo está correto"
echo "2. Teste no navegador: termux-open index.html"
echo "3. Suba para o GitHub: git add . && git commit -m 'V2.1 update' && git push"
